# SmartCube Plugins

Plugins oficiales de **SmartCube** para publicar información geográfica (terrenos y unidades de construcción) a trámites catastrales directamente desde herramientas GIS de escritorio.

Este monorepo agrupa los plugins por plataforma:

| Plataforma | Carpeta | Estado | Descripción |
|---|---|---|---|
| QGIS | [`qgis/`](qgis/) | ✅ Estable | Plugin **SmartCube Uploader** para QGIS 3.22+. Publica shapefiles a trámites vía API token. |
| ArcGIS | [`arcgis/`](arcgis/) | ✅ v1 (toolbox) | Python Toolbox **compartido** para ArcMap 10.8 y ArcGIS Pro. Publica shapefiles a trámites vía API token. |

## Estructura del repositorio

```
plugin/
├── qgis/                     # Plugin para QGIS
│   ├── smartcube_uploader/   # Código fuente del plugin (Python + PyQt5 + qgis.core)
│   ├── build.sh              # Empaqueta el plugin en un .zip instalable
│   └── dist/                 # Salida del build (no versionada)
├── arcgis/                   # Toolbox compartido ArcMap 10.8 + ArcGIS Pro
│   ├── toolbox/
│   │   ├── SmartCube.pyt     # Python Toolbox (única capa que toca arcpy)
│   │   └── smartcube_core/   # Lógica pura py2.7/py3 (API, config, etiquetas)
│   ├── tests/                # pytest — corre sin ArcGIS instalado
│   ├── build.sh              # Empaqueta el toolbox en un .zip distribuible
│   └── dist/                 # Salida del build (no versionada)
└── README.md
```

## Inicio rápido (QGIS)

```bash
cd qgis
bash build.sh
# Salida: qgis/dist/smartcube_uploader-<version>.zip
```

Luego en QGIS: **Plugins → Administrar e instalar plugins → Instalar desde ZIP**.

La guía completa de instalación, configuración (API token) y uso está en [`qgis/smartcube_uploader/README.md`](qgis/smartcube_uploader/README.md).

## Requisitos generales

- Backend SmartCube accesible por HTTPS.
- Usuario con rol `user-cargador-shape` activo.
- Token API vigente (se genera en SmartCube web: `/perfil` → **Tokens API**).

## Convenciones

- Cada plataforma vive en su propia carpeta raíz y es autocontenida (código, build y docs propios).
- Los artefactos de build (`dist/`, `*.zip`, add-ins empaquetados) **no** se versionan; se generan con el script de build de cada plataforma.
- El versionado de cada plugin se declara en su manifiesto de plataforma (`metadata.txt` en QGIS, `Config.daml` en ArcGIS Pro).

## Licencia

Uso interno de SmartCube. Todos los derechos reservados.
