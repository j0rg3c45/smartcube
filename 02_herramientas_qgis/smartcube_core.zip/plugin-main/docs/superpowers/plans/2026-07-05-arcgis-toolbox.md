# SmartCube ArcGIS Toolbox — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Un Python Toolbox (`.pyt`) compartido que publica shapefiles a trámites SmartCube desde ArcMap 10.8 y ArcGIS Pro.

**Architecture:** `smartcube_core/` es lógica pura (stdlib, sin arcpy, compatible py2.7/py3) testeable con pytest en Python 3 local; `SmartCube.pyt` es la única capa que toca arcpy y define 2 herramientas (Configurar conexión, Publicar shape). El contrato de API es idéntico al plugin QGIS.

**Tech Stack:** Python 2.7.18/3.x (subconjunto común), arcpy, stdlib (urllib, json, zipfile), pytest para unit tests.

## Global Constraints

- Compatible Python 2.7.18 (ArcMap 10.8) y Python 3.x (Pro): SIN f-strings, `from __future__ import unicode_literals`, `# -*- coding: utf-8 -*-` en todo archivo con no-ASCII.
- `smartcube_core/` NO importa `arcpy` jamás.
- Solo stdlib — cero dependencias externas en runtime.
- Endpoints y semántica idénticos a `qgis/smartcube_uploader/api_client.py`.
- Repo: `D:\aplicaciones\smartcube\aplicacion\plugin` (git). Working dir de los comandos: raíz del repo.
- Tests con el Python 3 local: `python -m pytest arcgis/tests -v`.
- Mensajes de commit terminan con `Co-Authored-By: Claude Fable 5 <noreply@anthropic.com>`.

---

### Task 1: `smartcube_core` — compat.py y labels.py

**Files:**
- Create: `arcgis/toolbox/smartcube_core/__init__.py`
- Create: `arcgis/toolbox/smartcube_core/compat.py`
- Create: `arcgis/toolbox/smartcube_core/labels.py`
- Test: `arcgis/tests/test_labels.py`, `arcgis/tests/conftest.py`

**Interfaces:**
- Produces: `compat.Request(url, data=None, headers=None, method=None)`, `compat.urlopen`, `compat.HTTPError`, `compat.URLError`, `compat.ensure_text(value) -> unicode`.
- Produces: `labels.build_tramite_label(dict) -> str`, `labels.build_predio_label(dict) -> str`, `labels.parse_id(str) -> int|None`.

- [ ] **Step 1: conftest para importar el paquete sin instalar**

`arcgis/tests/conftest.py`:
```python
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'toolbox'))
```

- [ ] **Step 2: Write the failing test**

`arcgis/tests/test_labels.py`:
```python
# -*- coding: utf-8 -*-
from smartcube_core import labels


def test_build_tramite_label():
    t = {'tramite_t_id': 42, 'radicado_numero': 'R-2026-001',
         'mutacion_tipo': 'Segunda', 'predios': [{}, {}]}
    assert labels.build_tramite_label(t) == 'R-2026-001 · Segunda · (2 predio/s) [#42]'


def test_build_tramite_label_datos_faltantes():
    t = {'tramite_t_id': 7}
    assert labels.build_tramite_label(t) == '? · ? · (0 predio/s) [#7]'


def test_build_predio_label_simple():
    p = {'predio_t_id': 9, 'npn': '760010001', 'npn_principal_esperado': '760010001',
         'npn_esperado_listo': True}
    assert labels.build_predio_label(p) == '760010001 [#9]'


def test_build_predio_label_npn_nuevo():
    p = {'predio_t_id': 9, 'npn': '760010001', 'npn_principal_esperado': '760010002',
         'npn_esperado_listo': True}
    assert labels.build_predio_label(p) == '760010001 → 760010002 (NUEVO) [#9]'


def test_build_predio_label_paso1_incompleto():
    p = {'predio_t_id': 9, 'npn': '760010001', 'npn_esperado_listo': False}
    out = labels.build_predio_label(p)
    assert 'paso 1 incompleto' in out and out.endswith('[#9]')


def test_parse_id():
    assert labels.parse_id('R-1 · Segunda · (2 predio/s) [#42]') == 42
    assert labels.parse_id('sin id') is None
    assert labels.parse_id('') is None
    assert labels.parse_id(None) is None
```

- [ ] **Step 3: Run test to verify it fails**

Run: `python -m pytest arcgis/tests/test_labels.py -v`
Expected: FAIL / ERROR con `ModuleNotFoundError: No module named 'smartcube_core'`.

- [ ] **Step 4: Write minimal implementation**

`arcgis/toolbox/smartcube_core/__init__.py`:
```python
# -*- coding: utf-8 -*-
"""Lógica pura del toolbox SmartCube (sin arcpy, compatible py2.7/py3)."""
__version__ = '0.1.0'
```

`arcgis/toolbox/smartcube_core/compat.py`:
```python
# -*- coding: utf-8 -*-
"""Shims de compatibilidad Python 2.7 (ArcMap 10.8) / Python 3 (ArcGIS Pro)."""
from __future__ import absolute_import, unicode_literals

import sys

PY2 = sys.version_info[0] == 2

if PY2:
    from urllib2 import Request as _Py2Request, urlopen, HTTPError, URLError  # noqa: F401

    class Request(_Py2Request):
        """urllib2.Request de py2 no acepta method=; este shim lo agrega."""

        def __init__(self, url, data=None, headers=None, method=None):
            _Py2Request.__init__(self, url, data=data, headers=headers or {})
            self._method = method

        def get_method(self):
            if self._method:
                return self._method
            return _Py2Request.get_method(self)
else:
    from urllib.request import Request, urlopen  # noqa: F401
    from urllib.error import HTTPError, URLError  # noqa: F401


def ensure_text(value):
    """Devuelve texto unicode a partir de bytes o texto."""
    if isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    return value
```

`arcgis/toolbox/smartcube_core/labels.py`:
```python
# -*- coding: utf-8 -*-
"""Etiquetas de dropdowns con el t_id embebido — evita estado compartido
entre eventos del diálogo de geoprocesamiento."""
from __future__ import absolute_import, unicode_literals

import re

_ID_RE = re.compile(r'\[#(\d+)\]\s*$')


def build_tramite_label(t):
    predios = t.get('predios') or []
    return '{0} · {1} · ({2} predio/s) [#{3}]'.format(
        t.get('radicado_numero') or '?',
        t.get('mutacion_tipo') or '?',
        len(predios),
        t['tramite_t_id'],
    )


def build_predio_label(p):
    npn = p.get('npn') or ''
    esperado = p.get('npn_principal_esperado') or ''
    if esperado and esperado != npn:
        base = '{0} → {1} (NUEVO)'.format(npn, esperado)
    else:
        base = npn or '?'
    if not p.get('npn_esperado_listo'):
        base += '  ⚠ paso 1 incompleto'
    return '{0} [#{1}]'.format(base, p['predio_t_id'])


def parse_id(label):
    m = _ID_RE.search(label or '')
    return int(m.group(1)) if m else None
```

- [ ] **Step 5: Run test to verify it passes**

Run: `python -m pytest arcgis/tests/test_labels.py -v`
Expected: 6 passed.

- [ ] **Step 6: Commit**

```bash
git add arcgis
git commit -m "feat(arcgis): smartcube_core con compat py2/py3 y etiquetas de dropdowns"
```

---

### Task 2: `smartcube_core/config.py`

**Files:**
- Create: `arcgis/toolbox/smartcube_core/config.py`
- Test: `arcgis/tests/test_config.py`

**Interfaces:**
- Produces: `config.load() -> {'backend_url': str, 'api_token': str}` (defaults `http://localhost:7000` / `''`), `config.save(backend_url, api_token) -> path`, `config.config_path() -> path` (respeta env `SMARTCUBE_ARCGIS_CONFIG` para tests).

- [ ] **Step 1: Write the failing test**

`arcgis/tests/test_config.py`:
```python
# -*- coding: utf-8 -*-
import io

from smartcube_core import config


def _usar_tmp(monkeypatch, tmp_path):
    path = tmp_path / 'cfg' / 'arcgis_config.json'
    monkeypatch.setenv('SMARTCUBE_ARCGIS_CONFIG', str(path))
    return path


def test_load_sin_archivo_devuelve_defaults(monkeypatch, tmp_path):
    _usar_tmp(monkeypatch, tmp_path)
    cfg = config.load()
    assert cfg == {'backend_url': 'http://localhost:7000', 'api_token': ''}


def test_save_y_load_roundtrip(monkeypatch, tmp_path):
    _usar_tmp(monkeypatch, tmp_path)
    config.save('https://jamundi.smartcubescol.com', 'smc_abc123')
    cfg = config.load()
    assert cfg == {'backend_url': 'https://jamundi.smartcubescol.com',
                   'api_token': 'smc_abc123'}


def test_load_archivo_corrupto_devuelve_defaults(monkeypatch, tmp_path):
    path = _usar_tmp(monkeypatch, tmp_path)
    path.parent.mkdir(parents=True)
    with io.open(str(path), 'w', encoding='utf-8') as f:
        f.write('{esto no es json')
    cfg = config.load()
    assert cfg == {'backend_url': 'http://localhost:7000', 'api_token': ''}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest arcgis/tests/test_config.py -v`
Expected: ERROR `ImportError: cannot import name 'config'` (o ModuleNotFoundError).

- [ ] **Step 3: Write minimal implementation**

`arcgis/toolbox/smartcube_core/config.py`:
```python
# -*- coding: utf-8 -*-
"""Configuración persistente (URL backend + token) en %APPDATA%\\SmartCube."""
from __future__ import absolute_import, unicode_literals

import io
import json
import os

DEFAULT_URL = 'http://localhost:7000'


def config_path():
    override = os.environ.get('SMARTCUBE_ARCGIS_CONFIG')
    if override:
        return override
    base = os.environ.get('APPDATA') or os.path.expanduser('~')
    return os.path.join(base, 'SmartCube', 'arcgis_config.json')


def load():
    try:
        with io.open(config_path(), 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            data = {}
    except (IOError, OSError, ValueError):
        data = {}
    return {
        'backend_url': data.get('backend_url') or DEFAULT_URL,
        'api_token': data.get('api_token') or '',
    }


def save(backend_url, api_token):
    path = config_path()
    directory = os.path.dirname(path)
    if directory and not os.path.isdir(directory):
        os.makedirs(directory)
    text = json.dumps(
        {'backend_url': backend_url, 'api_token': api_token},
        ensure_ascii=False, indent=2,
    )
    if isinstance(text, bytes):  # py2: dumps puede devolver str
        text = text.decode('utf-8')
    with io.open(path, 'w', encoding='utf-8') as f:
        f.write(text)
    return path
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest arcgis/tests/test_config.py -v`
Expected: 3 passed.

- [ ] **Step 5: Commit**

```bash
git add arcgis
git commit -m "feat(arcgis): config persistente en APPDATA con override por env para tests"
```

---

### Task 3: `smartcube_core/api_client.py`

**Files:**
- Create: `arcgis/toolbox/smartcube_core/api_client.py`
- Test: `arcgis/tests/test_api_client.py`

**Interfaces:**
- Consumes: `compat.Request/urlopen/HTTPError/URLError/ensure_text` (Task 1).
- Produces: `ApiError(message, status=None, body=None)` con atributos `.status`, `.body`; `SmartcubeClient(base_url, token)` con métodos `mis_tramites()`, `upload_terreno(tramite_t_id, predio_t_id, zip_path)`, `upload_terreno_segregacion(tramite_t_id, zip_path)`, `upload_construccion(tramite_t_id, zip_path)`, `_build_multipart(zip_path, boundary, extra_fields) -> bytes`.

- [ ] **Step 1: Write the failing test**

`arcgis/tests/test_api_client.py`:
```python
# -*- coding: utf-8 -*-
import io
import json

import pytest

from smartcube_core import api_client, compat


class FakeResponse(object):
    def __init__(self, payload):
        self._raw = json.dumps(payload).encode('utf-8')

    def read(self):
        return self._raw

    def close(self):
        pass


def test_mis_tramites_ok(monkeypatch):
    capturado = {}

    def fake_urlopen(req, timeout=None):
        capturado['url'] = req.get_full_url()
        capturado['token'] = req.headers.get('X-smartcube-token')
        return FakeResponse([{'tramite_t_id': 1}])

    monkeypatch.setattr(api_client.compat, 'urlopen', fake_urlopen)
    client = api_client.SmartcubeClient('http://x:7000/', 'smc_tok')
    assert client.mis_tramites() == [{'tramite_t_id': 1}]
    assert capturado['url'] == 'http://x:7000/api/gestion/cargas/mis-tramites/'
    assert capturado['token'] == 'smc_tok'


def test_http_error_extrae_detail(monkeypatch):
    def fake_urlopen(req, timeout=None):
        raise compat.HTTPError(
            req.get_full_url(), 401, 'Unauthorized', {},
            io.BytesIO(b'{"detail": "Token invalido"}'))

    monkeypatch.setattr(api_client.compat, 'urlopen', fake_urlopen)
    client = api_client.SmartcubeClient('http://x', 't')
    with pytest.raises(api_client.ApiError) as exc:
        client.mis_tramites()
    assert exc.value.status == 401
    assert 'Token invalido' in str(exc.value)


def test_url_error(monkeypatch):
    def fake_urlopen(req, timeout=None):
        raise compat.URLError('conexion rechazada')

    monkeypatch.setattr(api_client.compat, 'urlopen', fake_urlopen)
    client = api_client.SmartcubeClient('http://x', 't')
    with pytest.raises(api_client.ApiError) as exc:
        client.mis_tramites()
    assert 'No se pudo conectar' in str(exc.value)


def test_build_multipart(tmp_path):
    zip_file = tmp_path / 'capa.zip'
    zip_file.write_bytes(b'PK-fake-zip')
    client = api_client.SmartcubeClient('http://x', 't')
    body = client._build_multipart(str(zip_file), 'BOUND', {'predio_t_id': '9'})
    texto = body.decode('utf-8', 'replace')
    assert 'name="predio_t_id"' in texto
    assert '\r\n9\r\n' in texto
    assert 'name="zip"; filename="capa.zip"' in texto
    assert 'Content-Type: application/zip' in texto
    assert b'PK-fake-zip' in body
    assert texto.rstrip().endswith('--BOUND--')


def test_upload_terreno_arma_url_y_multipart(monkeypatch, tmp_path):
    zip_file = tmp_path / 'capa.zip'
    zip_file.write_bytes(b'PK')
    capturado = {}

    def fake_urlopen(req, timeout=None):
        capturado['url'] = req.get_full_url()
        capturado['method'] = req.get_method()
        capturado['ctype'] = req.headers.get('Content-type')
        return FakeResponse({'carga_t_id': 5, 'count_features': 2})

    monkeypatch.setattr(api_client.compat, 'urlopen', fake_urlopen)
    client = api_client.SmartcubeClient('http://x', 't')
    resp = client.upload_terreno(3, 9, str(zip_file))
    assert resp['carga_t_id'] == 5
    assert capturado['url'] == 'http://x/api/gestion/cargas/3/terreno/'
    assert capturado['method'] == 'POST'
    assert capturado['ctype'].startswith('multipart/form-data; boundary=')
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest arcgis/tests/test_api_client.py -v`
Expected: ERROR de import (`api_client` no existe).

- [ ] **Step 3: Write minimal implementation**

`arcgis/toolbox/smartcube_core/api_client.py`:
```python
# -*- coding: utf-8 -*-
"""Cliente HTTP del backend SmartCube — port del plugin QGIS, py2.7/py3."""
from __future__ import absolute_import, unicode_literals

import json
import os
import uuid

from . import compat


class ApiError(Exception):
    """Error de comunicación con el backend SmartCube."""

    def __init__(self, message, status=None, body=None):
        Exception.__init__(self, message)
        self.status = status
        self.body = body


class SmartcubeClient(object):
    """Cliente HTTP usando solo stdlib (sin requests)."""

    def __init__(self, base_url, token):
        self.base_url = (base_url or '').rstrip('/')
        self.token = token

    def _request(self, method, path, body=None, content_type='application/json'):
        url = self.base_url + path
        headers = {
            'X-Smartcube-Token': self.token or '',
            'Accept': 'application/json',
        }
        if body is not None and content_type == 'application/json':
            data = json.dumps(body).encode('utf-8')
            headers['Content-Type'] = 'application/json'
        else:
            data = body
            if content_type:
                headers['Content-Type'] = content_type

        req = compat.Request(url, data=data, headers=headers, method=method)
        try:
            resp = compat.urlopen(req, timeout=60)
            try:
                raw = resp.read()
            finally:
                resp.close()
            if raw:
                return json.loads(raw.decode('utf-8'))
            return None
        except compat.HTTPError as e:
            raw = e.read()
            try:
                body_json = json.loads(raw.decode('utf-8')) if raw else None
            except Exception:
                body_json = {'raw': compat.ensure_text(raw)}
            msg = None
            if isinstance(body_json, dict):
                msg = body_json.get('detail')
            raise ApiError(msg or 'HTTP {0}'.format(e.code),
                           status=e.code, body=body_json)
        except compat.URLError as e:
            raise ApiError('No se pudo conectar: {0}'.format(e.reason))

    def test_connection(self):
        return self._request('GET', '/api/gestion/cargas/mis-tramites/')

    def mis_tramites(self):
        return self._request('GET', '/api/gestion/cargas/mis-tramites/')

    def upload_terreno(self, tramite_t_id, predio_t_id, zip_path):
        return self._upload_zip(
            '/api/gestion/cargas/{0}/terreno/'.format(tramite_t_id),
            zip_path,
            extra_fields={'predio_t_id': '{0}'.format(predio_t_id)},
        )

    def upload_terreno_segregacion(self, tramite_t_id, zip_path):
        """Modo Asignación NPN: matriz rotulado con su NPN + polígonos nuevos
        sin NPN. No requiere predio_t_id."""
        return self._upload_zip(
            '/api/gestion/cargas/{0}/terreno-segregacion/'.format(tramite_t_id),
            zip_path,
        )

    def upload_construccion(self, tramite_t_id, zip_path):
        return self._upload_zip(
            '/api/gestion/cargas/{0}/construcciones/'.format(tramite_t_id),
            zip_path,
        )

    def _upload_zip(self, path, zip_path, extra_fields=None):
        boundary = uuid.uuid4().hex
        body = self._build_multipart(zip_path, boundary, extra_fields or {})
        return self._request(
            'POST', path, body=body,
            content_type='multipart/form-data; boundary={0}'.format(boundary),
        )

    def _build_multipart(self, zip_path, boundary, extra_fields):
        """Arma el cuerpo multipart/form-data en bytes."""
        crlf = b'\r\n'
        parts = []
        for name, value in extra_fields.items():
            parts.append('--{0}'.format(boundary).encode('utf-8'))
            parts.append(
                'Content-Disposition: form-data; name="{0}"'.format(name)
                .encode('utf-8'))
            parts.append(b'')
            parts.append('{0}'.format(value).encode('utf-8'))
        filename = os.path.basename(zip_path)
        parts.append('--{0}'.format(boundary).encode('utf-8'))
        parts.append(
            'Content-Disposition: form-data; name="zip"; filename="{0}"'
            .format(filename).encode('utf-8'))
        parts.append(b'Content-Type: application/zip')
        parts.append(b'')
        with open(zip_path, 'rb') as f:
            parts.append(f.read())
        parts.append('--{0}--'.format(boundary).encode('utf-8'))
        parts.append(b'')
        return crlf.join(parts)
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest arcgis/tests/test_api_client.py -v`
Expected: 5 passed.

- [ ] **Step 5: Run full suite**

Run: `python -m pytest arcgis/tests -v`
Expected: todo verde (labels + config + api_client).

- [ ] **Step 6: Commit**

```bash
git add arcgis
git commit -m "feat(arcgis): cliente API SmartCube compatible py2/py3 con multipart manual"
```

---

### Task 4: Guard de compatibilidad py2 (sin f-strings)

**Files:**
- Test: `arcgis/tests/test_py2_compat.py`

**Interfaces:**
- Consumes: los archivos fuente de `arcgis/toolbox/` (incluido `SmartCube.pyt` cuando exista — el glob lo recoge automáticamente).

- [ ] **Step 1: Write the test (pasa ya, protege el futuro)**

`arcgis/tests/test_py2_compat.py`:
```python
# -*- coding: utf-8 -*-
"""Guard: el código que corre dentro de ArcMap (py2.7) no puede usar f-strings."""
import io
import glob
import os
import re

TOOLBOX_DIR = os.path.join(os.path.dirname(__file__), '..', 'toolbox')
F_STRING = re.compile(r"""(?<![A-Za-z0-9_])[fF]['"]""")


def _fuentes():
    patrones = [os.path.join(TOOLBOX_DIR, '*.pyt'),
                os.path.join(TOOLBOX_DIR, 'smartcube_core', '*.py')]
    rutas = []
    for p in patrones:
        rutas.extend(glob.glob(p))
    return rutas


def test_hay_fuentes():
    assert len(_fuentes()) >= 4


def test_sin_f_strings():
    infractores = []
    for ruta in _fuentes():
        with io.open(ruta, 'r', encoding='utf-8') as f:
            for num, linea in enumerate(f, 1):
                if F_STRING.search(linea):
                    infractores.append('{0}:{1}: {2}'.format(
                        os.path.basename(ruta), num, linea.strip()))
    assert not infractores, 'f-strings prohibidas (py2.7):\n' + '\n'.join(infractores)
```

- [ ] **Step 2: Run — debe pasar ya (core tiene 5 módulos ≥ 4); el guard protege contra f-strings futuras y escaneará el .pyt cuando exista**

Run: `python -m pytest arcgis/tests/test_py2_compat.py -v`
Expected: 2 passed (core tiene `__init__`, `compat`, `config`, `labels`, `api_client` = 5 archivos ≥ 4).

- [ ] **Step 3: Commit**

```bash
git add arcgis/tests/test_py2_compat.py
git commit -m "test(arcgis): guard anti f-strings para compatibilidad ArcMap py2.7"
```

---

### Task 5: `SmartCube.pyt` — el toolbox

**Files:**
- Create: `arcgis/toolbox/SmartCube.pyt`

**Interfaces:**
- Consumes: `config.load/save`, `api_client.SmartcubeClient/ApiError`, `labels.build_tramite_label/build_predio_label/parse_id`.
- Produces: clases `Toolbox`, `ConfigurarConexion`, `PublicarShape` (contrato arcpy estándar: `getParameterInfo`, `updateParameters`, `updateMessages`, `execute`).

- [ ] **Step 1: Write implementation**

`arcgis/toolbox/SmartCube.pyt`:
```python
# -*- coding: utf-8 -*-
"""SmartCube Toolbox — publica shapefiles a trámites SmartCube.

Compatible con ArcMap 10.8 (Python 2.7) y ArcGIS Pro (Python 3).
Instalación: Add Toolbox → este archivo. Ver arcgis/README.md.
"""
from __future__ import unicode_literals

import os
import shutil
import sys
import tempfile
import zipfile

import arcpy

_DIR = os.path.dirname(os.path.abspath(__file__))
if _DIR not in sys.path:
    sys.path.insert(0, _DIR)

from smartcube_core import api_client, config, labels  # noqa: E402

DESTINO_TERRENO = 'Terreno'
DESTINO_SEGREGACION = 'Terreno · Asignación NPN'
DESTINO_CONSTRUCCION = 'Construcción'
DESTINOS = [DESTINO_TERRENO, DESTINO_SEGREGACION, DESTINO_CONSTRUCCION]

# Cache de trámites del último getParameterInfo (vive mientras el .pyt esté
# cargado; se refresca cada vez que se abre la herramienta).
_TRAMITES = []


def _client():
    cfg = config.load()
    return api_client.SmartcubeClient(cfg['backend_url'], cfg['api_token'])


def _tramite_por_label(label):
    tid = labels.parse_id(label)
    for t in _TRAMITES:
        if t.get('tramite_t_id') == tid:
            return t
    return None


def _predio_por_label(tramite, label):
    pid = labels.parse_id(label)
    for p in (tramite or {}).get('predios') or []:
        if p.get('predio_t_id') == pid:
            return p
    return None


class Toolbox(object):
    def __init__(self):
        self.label = 'SmartCube'
        self.alias = 'smartcube'
        self.tools = [ConfigurarConexion, PublicarShape]


class ConfigurarConexion(object):
    def __init__(self):
        self.label = '1. Configurar conexión'
        self.description = ('Guarda la URL del backend SmartCube y el token API, '
                            'y prueba la conexión listando tus trámites.')
        self.canRunInBackground = False

    def getParameterInfo(self):
        cfg = config.load()
        url = arcpy.Parameter(
            displayName='URL del backend SmartCube',
            name='backend_url', datatype='GPString',
            parameterType='Required', direction='Input')
        url.value = cfg['backend_url']
        token = arcpy.Parameter(
            displayName='Token API (SmartCube web: /perfil → Tokens API)',
            name='api_token', datatype='GPString',
            parameterType='Required', direction='Input')
        if cfg['api_token']:
            token.value = cfg['api_token']
        return [url, token]

    def updateParameters(self, parameters):
        return

    def updateMessages(self, parameters):
        return

    def execute(self, parameters, messages):
        backend_url = (parameters[0].valueAsText or '').strip()
        api_token = (parameters[1].valueAsText or '').strip()
        path = config.save(backend_url, api_token)
        messages.addMessage('Configuración guardada en {0}'.format(path))
        client = api_client.SmartcubeClient(backend_url, api_token)
        try:
            data = client.test_connection() or []
        except api_client.ApiError as e:
            messages.addErrorMessage(
                '✗ Error probando conexión: {0} (status={1})'.format(e, e.status))
            return
        messages.addMessage(
            '✓ Conexión exitosa. {0} trámite(s) accesibles.'.format(len(data)))


class PublicarShape(object):
    def __init__(self):
        self.label = '2. Publicar shape'
        self.description = ('Exporta una capa a Shapefile.zip y la publica a un '
                            'trámite SmartCube (terreno o construcción). Si la capa '
                            'tiene selección activa, solo se publica lo seleccionado.')
        self.canRunInBackground = False

    def getParameterInfo(self):
        global _TRAMITES
        tramite = arcpy.Parameter(
            displayName='Trámite', name='tramite', datatype='GPString',
            parameterType='Required', direction='Input')
        tramite.filter.type = 'ValueList'
        try:
            _TRAMITES = _client().mis_tramites() or []
            tramite.filter.list = [labels.build_tramite_label(t) for t in _TRAMITES]
        except api_client.ApiError as e:
            _TRAMITES = []
            tramite.filter.list = [
                '✗ {0} — ejecuta "1. Configurar conexión"'.format(e)]

        destino = arcpy.Parameter(
            displayName='Capa destino', name='capa_destino', datatype='GPString',
            parameterType='Required', direction='Input')
        destino.filter.type = 'ValueList'
        destino.filter.list = DESTINOS
        destino.value = DESTINO_TERRENO

        predio = arcpy.Parameter(
            displayName='Predio (solo para Terreno)', name='predio',
            datatype='GPString', parameterType='Optional', direction='Input')
        predio.filter.type = 'ValueList'

        capa = arcpy.Parameter(
            displayName='Capa a publicar', name='capa',
            datatype='GPFeatureLayer', parameterType='Required',
            direction='Input')
        return [tramite, destino, predio, capa]

    def updateParameters(self, parameters):
        tramite_p, destino_p, predio_p = parameters[0], parameters[1], parameters[2]
        es_terreno = destino_p.valueAsText == DESTINO_TERRENO
        predio_p.enabled = es_terreno
        t = _tramite_por_label(tramite_p.valueAsText)
        if t is not None:
            predio_p.filter.list = [
                labels.build_predio_label(p) for p in t.get('predios') or []]
        if not es_terreno:
            predio_p.value = None

    def updateMessages(self, parameters):
        tramite_p, destino_p, predio_p = parameters[0], parameters[1], parameters[2]
        label = tramite_p.valueAsText or ''
        if label.startswith('✗'):
            tramite_p.setErrorMessage(
                'No se pudieron cargar los trámites. Ejecuta "1. Configurar '
                'conexión" y vuelve a abrir esta herramienta.')
            return
        es_terreno = destino_p.valueAsText == DESTINO_TERRENO
        if es_terreno and label and not predio_p.valueAsText:
            predio_p.setErrorMessage('Selecciona un predio para destino Terreno.')
            return
        if es_terreno and predio_p.valueAsText:
            t = _tramite_por_label(label)
            p = _predio_por_label(t, predio_p.valueAsText)
            if p is not None and not p.get('npn_esperado_listo'):
                predio_p.setWarningMessage(
                    p.get('aviso') or 'NPN esperado aún no disponible '
                    '(paso 1 incompleto).')
            elif p is not None:
                npn = p.get('npn_principal_esperado') or ''
                es_nuevo = npn and npn != (p.get('npn') or '')
                sufijo = ' (NPN del predio NUEVO asignado en Paso 1)' if es_nuevo else ''
                predio_p.setWarningMessage(
                    'NPN a rotular en el polígono principal del shape: '
                    '{0}{1}'.format(npn, sufijo))

    def execute(self, parameters, messages):
        tramite_label = parameters[0].valueAsText or ''
        destino = parameters[1].valueAsText
        predio_label = parameters[2].valueAsText or ''
        capa = parameters[3].value

        tramite_id = labels.parse_id(tramite_label)
        if not tramite_id:
            messages.addErrorMessage(
                'Trámite inválido. Vuelve a abrir la herramienta (o ejecuta '
                '"1. Configurar conexión" si el problema persiste).')
            return
        predio_id = None
        if destino == DESTINO_TERRENO:
            predio_id = labels.parse_id(predio_label)
            if not predio_id:
                messages.addErrorMessage('Selecciona un predio para destino Terreno.')
                return

        tmpdir = tempfile.mkdtemp(prefix='smartcube_')
        try:
            shp_path = os.path.join(tmpdir, 'capa.shp')
            messages.addMessage('Exportando capa a Shapefile temporal…')
            arcpy.management.CopyFeatures(capa, shp_path)

            zip_path = os.path.join(tmpdir, 'capa.zip')
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for ext in ('shp', 'dbf', 'shx', 'prj', 'cpg'):
                    p = os.path.join(tmpdir, 'capa.' + ext)
                    if os.path.exists(p):
                        zf.write(p, 'capa.' + ext)

            client = _client()
            messages.addMessage(
                'Publicando → {0} (trámite #{1})…'.format(destino, tramite_id))
            if destino == DESTINO_TERRENO:
                resp = client.upload_terreno(tramite_id, predio_id, zip_path)
                messages.addMessage(
                    '✓ Carga creada (id={0}). {1} features ({2} colindantes).'.format(
                        resp.get('carga_t_id'), resp.get('count_features'),
                        resp.get('count_colindantes', 0)))
            elif destino == DESTINO_SEGREGACION:
                resp = client.upload_terreno_segregacion(tramite_id, zip_path)
                messages.addMessage(
                    '✓ Carga de segregación creada (id={0}). {1} predios nuevos '
                    'por numerar (matriz {2}).'.format(
                        resp.get('carga_t_id'), resp.get('count_nuevos', 0),
                        resp.get('principal_npn', '?')))
            else:
                resp = client.upload_construccion(tramite_id, zip_path)
                messages.addMessage(
                    '✓ Carga creada (id={0}). {1} features ({2} UC).'.format(
                        resp.get('carga_t_id'), resp.get('count_features'),
                        len(resp.get('identificadores_uc') or [])))
            for w in resp.get('warnings') or []:
                messages.addWarningMessage(w)
            messages.addMessage('Shape publicado correctamente.')
        except api_client.ApiError as e:
            if e.status == 401:
                messages.addErrorMessage(
                    '✗ Token inválido o revocado. Genera uno nuevo en SmartCube '
                    'web (/perfil → Tokens API) y ejecuta "1. Configurar conexión".')
            else:
                messages.addErrorMessage('✗ {0} (status={1})'.format(e, e.status))
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
```

- [ ] **Step 2: Smoke checks (sin arcpy no se puede importar; validar sintaxis py3 y guard py2)**

Run: `python -m py_compile arcgis/toolbox/SmartCube.pyt`
Expected: exit 0, sin salida.

Run: `python -m pytest arcgis/tests -v`
Expected: todo verde; `test_py2_compat` ahora también escanea el `.pyt`.

- [ ] **Step 3: Commit**

```bash
git add arcgis/toolbox/SmartCube.pyt
git commit -m "feat(arcgis): toolbox SmartCube.pyt con Configurar conexion y Publicar shape"
```

---

### Task 6: build.sh, README de arcgis y tabla del README raíz

**Files:**
- Create: `arcgis/build.sh`
- Rewrite: `arcgis/README.md` (reemplaza el placeholder "planeado")
- Modify: `README.md` (tabla de plataformas: fila ArcGIS pasa de 🚧 Planeado a ✅ toolbox v1)

**Interfaces:**
- Consumes: `__version__` en `arcgis/toolbox/smartcube_core/__init__.py` (Task 1).

- [ ] **Step 1: build.sh (mismo patrón del de qgis, con fallback Python)**

`arcgis/build.sh`:
```bash
#!/usr/bin/env bash
# Empaqueta el toolbox SmartCube en un .zip distribuible.
#
# Salida: arcgis/dist/smartcube_toolbox-<version>.zip
set -euo pipefail

cd "$(dirname "$0")"

VERSION=$(grep "__version__" toolbox/smartcube_core/__init__.py | cut -d"'" -f2)
OUTDIR="dist"
ZIP_NAME="smartcube_toolbox-${VERSION}.zip"

mkdir -p "$OUTDIR"
rm -f "$OUTDIR/$ZIP_NAME"

# Usa `zip` si está disponible; si no (p.ej. Git Bash en Windows), cae a Python.
if command -v zip >/dev/null 2>&1; then
  zip -r "$OUTDIR/$ZIP_NAME" toolbox \
    -x "toolbox/**/__pycache__/*" \
    -x "toolbox/**/*.pyc"
else
  PYTHON=$(command -v python3 || command -v python)
  "$PYTHON" - "$OUTDIR/$ZIP_NAME" <<'EOF'
import sys, zipfile
from pathlib import Path

dest = Path(sys.argv[1])
with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
    for path in sorted(Path("toolbox").rglob("*")):
        if "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        if path.is_file():
            zf.write(path, path.as_posix())
EOF
fi

echo "✓ Generado: arcgis/$OUTDIR/$ZIP_NAME"
```

- [ ] **Step 2: README de arcgis**

Reescribir `arcgis/README.md` con: qué es (toolbox compartido ArcMap 10.8 + Pro), instalación (descomprimir zip o clonar; ArcToolbox → Add Toolbox en ArcMap; Catalog → Toolboxes → Add Toolbox en Pro), configuración (herramienta 1, token de /perfil), uso (herramienta 2 con los 4 parámetros y nota de selección activa), tabla de errores comunes (401/403/400/409, misma del README QGIS), sección Desarrollo (pytest, guard f-strings, regla py2.7), y **Checklist E2E** (ambas plataformas): configurar → probar conexión → publicar Terreno / Asignación NPN / Construcción → error de token revocado → error NPN no coincide.

- [ ] **Step 3: Actualizar tabla del README raíz**

En `README.md` raíz cambiar la fila ArcGIS a:
```markdown
| ArcGIS  | [`arcgis/`](arcgis/) | ✅ v1 (toolbox) | Python Toolbox **compartido** para ArcMap 10.8 y ArcGIS Pro. Publica shapefiles a trámites vía API token. |
```
y actualizar el árbol de estructura para reflejar `arcgis/toolbox/`.

- [ ] **Step 4: Verificar build**

Run: `bash arcgis/build.sh` y luego inspeccionar el zip:
`python -c "import zipfile; print('\n'.join(zipfile.ZipFile('arcgis/dist/smartcube_toolbox-0.1.0.zip').namelist()))"`
Expected: `toolbox/SmartCube.pyt` + `toolbox/smartcube_core/*.py` (5 módulos), sin `__pycache__`.

- [ ] **Step 5: Full suite final**

Run: `python -m pytest arcgis/tests -v`
Expected: todo verde.

- [ ] **Step 6: Commit y push**

```bash
git add -A
git commit -m "docs(arcgis): build.sh, README con checklist E2E y tabla raiz actualizada"
git push origin main
```

---

### Task 7: E2E manual (usuario)

No automatizable aquí: seguir el **Checklist E2E** del `arcgis/README.md` en ArcMap 10.8 y ArcGIS Pro contra el backend dev (`http://localhost:7000`), con un usuario con rol `user-cargador-shape` y un trámite con invitación de cargador. Reportar cualquier desviación como issue.
