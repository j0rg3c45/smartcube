# SmartCube Uploader — Python Toolbox para ArcMap y ArcGIS Pro

**Fecha:** 2026-07-05
**Estado:** Aprobado por el usuario (diseño validado en sesión)

## Objetivo

Replicar la funcionalidad esencial del plugin QGIS (`qgis/smartcube_uploader/`) en las
plataformas Esri que usa la oficina: **ArcMap 10.8** (Python 2.7.18) y **ArcGIS Pro**
(Python 3.x), con **un solo Python Toolbox (`.pyt`) compartido** — el mismo archivo se
agrega en ambas plataformas.

Alcance v1 (decidido con el usuario): **Configurar conexión + Publicar shape**.
La descarga de capas catastrales con simbología queda para una v2.

## Decisiones tomadas

| Decisión | Valor | Razón |
|---|---|---|
| Enfoque | Un `.pyt` compartido (opción A) | Cero duplicación; reutiliza el contrato de API probado con QGIS |
| Alcance v1 | Configuración + Publicar shape | Es el valor central; simbología es lo más caro de portar |
| Plataformas | ArcMap 10.8 + ArcGIS Pro | Confirmado por el usuario; 10.8 = Python 2.7.18, TLS 1.2 OK |
| Testing | Unit sin arcpy + E2E manual en ambas | El usuario tiene ambas plataformas disponibles |
| UI | Diálogo estándar de geoprocesamiento | Suficiente para 4 campos + ejecutar; sin ventanas custom |

## Estructura de archivos

```
arcgis/
├── toolbox/
│   ├── SmartCube.pyt            # Toolbox: 2 herramientas (única capa que toca arcpy)
│   └── smartcube_core/          # Lógica pura, SIN arcpy, compatible py2.7/py3
│       ├── __init__.py
│       ├── compat.py            # Shims urllib2/urllib.request, Request con method
│       ├── api_client.py        # Port del api_client de QGIS (mismos endpoints)
│       └── config.py            # Lee/escribe %APPDATA%\SmartCube\arcgis_config.json
├── tests/                       # pytest sobre smartcube_core (corre sin ArcGIS)
├── build.sh                     # Zipea toolbox/ → dist/smartcube_toolbox-<version>.zip
└── README.md                    # Instalación ArcMap + Pro, configuración, uso, errores
```

Instalación por el usuario final: agregar `SmartCube.pyt` una vez —
ArcMap: **ArcToolbox → Add Toolbox**; Pro: **Catalog → Toolboxes → Add Toolbox**.

El `.pyt` agrega su propia carpeta a `sys.path` para importar `smartcube_core`.

## Herramienta «1. Configurar conexión»

Parámetros:
- **URL del backend** (GPString; default = valor guardado o `http://localhost:7000`).
- **Token API** (GPString; el usuario lo genera en SmartCube web `/perfil` → Tokens API).

Ejecución: guarda `%APPDATA%\SmartCube\arcgis_config.json` y prueba la conexión con
`GET /api/gestion/cargas/mis-tramites/`. Reporta «✓ Conexión exitosa, N trámite(s)» o el
error detallado. Equivale a Configuración + Probar conexión del plugin QGIS.

El token se guarda en texto plano — mismo nivel de protección que QSettings en QGIS;
documentado en el README.

## Herramienta «2. Publicar shape»

Parámetros:
1. **Trámite** (GPString con `filter.list`): poblado desde el API al abrir la herramienta
   (`getParameterInfo`). Formato de etiqueta: `radicado · mutación · (N predios) [#tramite_id]`.
   El `t_id` va embebido en la etiqueta y se parsea con regex — no se depende de estado
   compartido entre eventos del diálogo.
2. **Capa destino** (GPString con `filter.list`): `Terreno` / `Terreno · Asignación NPN` /
   `Construcción`.
3. **Predio** (GPString con `filter.list`): habilitado solo para destino `Terreno`; poblado
   en `updateParameters` con los predios del trámite elegido. Etiqueta:
   `npn [#predio_t_id]`, o `npn → npn_esperado (NUEVO) [#id]` si difiere, con sufijo
   `⚠ paso 1 incompleto` cuando `npn_esperado_listo` es falso. `updateMessages` replica el
   hint del NPN esperado (info) y el aviso de paso 1 incompleto (warning).
4. **Capa a publicar** (GPFeatureLayer): capa del mapa o ruta a shapefile/feature class.

Ejecución:
1. Exporta la capa a shapefile temporal con `arcpy.management.CopyFeatures`
   (compatible 10.8 y Pro). El CRS se deja tal cual — el backend transforma (mismo
   comportamiento que QGIS).
2. Zipea `shp/dbf/shx/prj/cpg` con `zipfile` (stdlib).
3. POST según destino — endpoints idénticos a QGIS:
   - Terreno → `POST /api/gestion/cargas/<tramite>/terreno/` con `predio_t_id`.
   - Asignación NPN → `POST /api/gestion/cargas/<tramite>/terreno-segregacion/`.
   - Construcción → `POST /api/gestion/cargas/<tramite>/construcciones/`.
4. Reporta `carga_t_id`, conteo de features/colindantes/UC/nuevos y `warnings` del
   backend con `arcpy.AddMessage`/`AddWarning`. Limpia el temporal en `finally`.

Comportamiento heredado de ArcGIS (documentado como feature): si la capa tiene selección
activa, `CopyFeatures` exporta solo lo seleccionado (QGIS siempre sube la capa completa).

## Compatibilidad Python 2.7 / 3.x

`smartcube_core` se escribe en el subconjunto común:
- Sin f-strings (usar `.format()`); `from __future__ import unicode_literals`.
- Imports condicionales: `urllib2` (py2) vs `urllib.request`/`urllib.error` (py3),
  concentrados en `compat.py`.
- Shim de `Request` con método HTTP explícito (el `urllib2.Request` de py2 no acepta
  `method=`).
- Multipart armado en bytes a mano (igual que QGIS). Solo stdlib; `arcpy` únicamente en
  el `.pyt`.

## Manejo de errores

Misma taxonomía del plugin QGIS: `ApiError(message, status, body)` extrayendo `detail`
del JSON del backend.

- **Carga de trámites falla** (al abrir Publicar shape): el parámetro Trámite muestra un
  único ítem `✗ <error> — ejecuta "1. Configurar conexión"` y `updateMessages` marca error.
- **Ejecución falla:** `arcpy.AddError` con el detalle. Tabla de errores en README
  (mismos casos que QGIS): 401 token revocado → reconfigurar; 403 no invitado al trámite;
  400 NPN no coincide; 409 trámite cerrado; timeout/red.

## Testing

- **Unitario (sin ArcGIS, pytest en Python 3 local):** armado del multipart byte a byte,
  parseo de respuestas y errores (`detail`, status), lectura/escritura de config con
  archivo inexistente/corrupto, parseo del `[#id]` embebido en etiquetas, armado de
  etiquetas de trámite/predio. `smartcube_core` no importa `arcpy`, así que corre en CI o
  local sin licencias.
- **Compatibilidad py2.7:** se valida en el E2E de ArcMap (no se instala un 2.7 local).
  Regla de estilo verificable: grep de f-strings prohibidas en `smartcube_core/`.
- **E2E manual (checklist en README, ambas plataformas):** contra backend dev
  (`localhost:7000`): configurar → probar conexión → publicar Terreno, Asignación NPN y
  Construcción con shapes de prueba → errores (token revocado, NPN que no coincide).

## Fuera de alcance (v1)

- Cargar capas catastrales con simbología (v2 si se necesita).
- Add-in nativo de ArcGIS Pro con ribbon/dockpane (posible v3; este diseño no lo bloquea).
- Cambios en el backend: el contrato de API existente se usa tal cual.
