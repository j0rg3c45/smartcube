#!/usr/bin/env bash
# Empaqueta el plugin SmartCube Uploader en un .zip instalable.
#
# Salida: qgis/dist/smartcube_uploader-<version>.zip
set -euo pipefail

cd "$(dirname "$0")"

VERSION=$(grep '^version=' smartcube_uploader/metadata.txt | cut -d= -f2)
OUTDIR="dist"
ZIP_NAME="smartcube_uploader-${VERSION}.zip"

mkdir -p "$OUTDIR"
rm -f "$OUTDIR/$ZIP_NAME"

# QGIS espera que el ZIP contenga una carpeta del plugin en la raíz.
# Usa `zip` si está disponible; si no (p.ej. Git Bash en Windows), cae a Python.
if command -v zip >/dev/null 2>&1; then
  zip -r "$OUTDIR/$ZIP_NAME" smartcube_uploader \
    -x "smartcube_uploader/__pycache__/*" \
    -x "smartcube_uploader/.git*"
else
  PYTHON=$(command -v python3 || command -v python)
  "$PYTHON" - "$OUTDIR/$ZIP_NAME" <<'EOF'
import sys, zipfile
from pathlib import Path

dest = Path(sys.argv[1])
with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
    for path in sorted(Path("smartcube_uploader").rglob("*")):
        if "__pycache__" in path.parts or path.name.startswith(".git"):
            continue
        if path.is_file():
            zf.write(path, path.as_posix())
EOF
fi

echo "✓ Generado: qgis/$OUTDIR/$ZIP_NAME"
