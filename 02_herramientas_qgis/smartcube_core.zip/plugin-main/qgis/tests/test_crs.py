# -*- coding: utf-8 -*-
"""Validación del sistema de referencia antes de publicar una capa.

El backend deduce el CRS del .prj del ZIP, y esa deducción falla en abierto
hacia 4326: un shape en metros exportado sin .prj (o con un .prj que la
heurística no reconoce) entra al borrador etiquetado como grados y revienta al
commitear. La defensa barata es no dejar que salga de aquí.
"""
from smartcube_uploader.crs import (
    CRS_SOPORTADOS,
    authid_desde_codigo_epsg,
    es_soportado,
    mensaje_crs_no_soportado,
)


class TestAuthidDesdeCodigoEpsg(object):
    """ArcGIS expone el CRS como código EPSG numérico, no como authid."""

    def test_codigo_valido(self):
        assert authid_desde_codigo_epsg(9377) == 'EPSG:9377'

    def test_codigo_cero_es_capa_sin_crs(self):
        """`factoryCode` vale 0 cuando la capa no tiene CRS definido."""
        assert authid_desde_codigo_epsg(0) == ''

    def test_codigo_ausente(self):
        assert authid_desde_codigo_epsg(None) == ''

    def test_codigo_como_texto(self):
        assert authid_desde_codigo_epsg('4326') == 'EPSG:4326'

    def test_codigo_no_numerico(self):
        assert authid_desde_codigo_epsg('desconocido') == ''


class TestEsSoportado(object):
    def test_wgs84_es_soportado(self):
        assert es_soportado('EPSG:4326')

    def test_magna_sirgas_origen_unico_es_soportado(self):
        assert es_soportado('EPSG:9377')

    def test_magna_sirgas_con_codigo_esri_es_soportado(self):
        """Mismo CRS, otro catálogo.

        Un `.prj` escrito en WKT estilo ESRI ("MAGNA-SIRGAS_Origen-Nacional")
        no trae nodos AUTHORITY, así que QGIS no puede resolverlo a EPSG:9377 y
        lo etiqueta ESRI:103599. Es el mismo origen único nacional y el backend
        lo reconoce por nombre, así que bloquearlo era un falso positivo.
        """
        assert es_soportado('ESRI:103599')

    def test_codigo_esri_llegando_como_epsg_es_soportado(self):
        """ArcGIS expone 103599 en `factoryCode` y el helper lo prefija EPSG."""
        assert es_soportado('EPSG:103599')

    def test_crs84_es_soportado(self):
        """OGC:CRS84 es WGS 84 en orden lon/lat: el 4326 de los GeoJSON."""
        assert es_soportado('OGC:CRS84')

    def test_los_equivalentes_tambien_se_normalizan(self):
        assert es_soportado('  esri:103599 ')

    def test_magna_bogota_no_es_soportado(self):
        """3116 es el origen antiguo: el backend no lo maneja."""
        assert not es_soportado('EPSG:3116')

    def test_web_mercator_no_es_soportado(self):
        assert not es_soportado('EPSG:3857')

    def test_capa_sin_crs_no_es_soportada(self):
        assert not es_soportado('')
        assert not es_soportado(None)

    def test_el_authid_se_normaliza(self):
        assert es_soportado('epsg:9377')
        assert es_soportado('  EPSG:4326  ')


class TestMensaje(object):
    def test_nombra_el_crs_encontrado_y_los_aceptados(self):
        msg = mensaje_crs_no_soportado('EPSG:3116')

        assert 'EPSG:3116' in msg
        assert 'EPSG:9377' in msg
        assert 'EPSG:4326' in msg

    def test_capa_sin_crs_lo_dice_explicitamente(self):
        msg = mensaje_crs_no_soportado('')

        assert 'sin sistema de referencia' in msg.lower()

    def test_los_dos_crs_soportados_estan_documentados(self):
        assert set(CRS_SOPORTADOS) == {'EPSG:4326', 'EPSG:9377'}
        assert 'MAGNA' in CRS_SOPORTADOS['EPSG:9377']
