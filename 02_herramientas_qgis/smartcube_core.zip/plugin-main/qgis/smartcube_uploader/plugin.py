"""SmartCube Uploader — registro del plugin en QGIS."""

import os

from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMessageBox

from .settings_dialog import SettingsDialog, get_settings
from .upload_dialog import UploadDialog


class SmartcubeUploaderPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.menu = '&SmartCube'
        self.toolbar = None

    def _icon(self, nombre):
        return QIcon(os.path.join(os.path.dirname(__file__), nombre))

    def initGui(self):
        # Barra de herramientas propia (separada de la barra genérica de complementos)
        self.toolbar = self.iface.addToolBar('SmartCube')
        self.toolbar.setObjectName('SmartCubeToolbar')

        action_upload = QAction(
            self._icon('icon_upload.svg'), 'Publicar shape…', self.iface.mainWindow(),
        )
        action_upload.triggered.connect(self._abrir_upload)
        self.iface.addPluginToMenu(self.menu, action_upload)
        self.toolbar.addAction(action_upload)
        self.actions.append(action_upload)

        action_cartografia = QAction(
            self._icon('icon_cartografia.svg'), 'Cargar capas catastrales…',
            self.iface.mainWindow(),
        )
        action_cartografia.triggered.connect(self._abrir_cartografia)
        self.iface.addPluginToMenu(self.menu, action_cartografia)
        self.toolbar.addAction(action_cartografia)
        self.actions.append(action_cartografia)

        # Botón propio y no una opción del desplegable de «Publicar shape»: es
        # otro flujo. Aquí no hay trámite ni resolución, se corrige la
        # geometría de predios ya inscritos y un admin lo aprueba.
        action_actualizacion = QAction(
            self._icon('icon_actualizacion.svg'), 'Actualización cartográfica…',
            self.iface.mainWindow(),
        )
        action_actualizacion.triggered.connect(self._abrir_actualizacion)
        self.iface.addPluginToMenu(self.menu, action_actualizacion)
        self.toolbar.addAction(action_actualizacion)
        self.actions.append(action_actualizacion)

        action_settings = QAction(
            self._icon('icon_settings.svg'), 'Configuración…', self.iface.mainWindow(),
        )
        action_settings.triggered.connect(self._abrir_settings)
        self.iface.addPluginToMenu(self.menu, action_settings)
        self.toolbar.addAction(action_settings)
        self.actions.append(action_settings)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
        self.actions = []
        if self.toolbar is not None:
            del self.toolbar
            self.toolbar = None

    def _abrir_upload(self):
        cfg = get_settings()
        if not cfg['backend_url'] or not cfg['api_token']:
            QMessageBox.information(
                self.iface.mainWindow(), 'SmartCube',
                'Primero configura URL y token en Plugins → SmartCube → Configuración.',
            )
            self._abrir_settings()
            return
        dlg = UploadDialog(self.iface.mainWindow())
        dlg.exec_()

    def _abrir_actualizacion(self):
        cfg = get_settings()
        if not cfg['backend_url'] or not cfg['api_token']:
            QMessageBox.information(
                self.iface.mainWindow(), 'SmartCube',
                'Primero configura URL y token en Plugins → SmartCube → Configuración.',
            )
            self._abrir_settings()
            return
        from .actualizacion_dialog import ActualizacionDialog
        dlg = ActualizacionDialog(self.iface.mainWindow())
        dlg.exec_()

    def _abrir_cartografia(self):
        cfg = get_settings()
        if not cfg['backend_url'] or not cfg['api_token']:
            QMessageBox.information(
                self.iface.mainWindow(), 'SmartCube',
                'Primero configura URL y token en Plugins → SmartCube → Configuración.',
            )
            self._abrir_settings()
            return
        from .cartografia_dialog import CartografiaDialog
        dlg = CartografiaDialog(self.iface, self.iface.mainWindow())
        dlg.exec_()

    def _abrir_settings(self):
        dlg = SettingsDialog(self.iface.mainWindow())
        dlg.exec_()
