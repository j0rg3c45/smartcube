"""Diálogo principal de carga de shape a SmartCube."""

import os
import tempfile
import zipfile

from qgis.core import QgsProject, QgsVectorFileWriter, QgsCoordinateReferenceSystem
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QComboBox, QDialog, QHBoxLayout, QLabel, QMessageBox, QPushButton,
    QTextEdit, QVBoxLayout, QWidget, QFormLayout,
)

from .api_client import ApiError, SmartcubeClient
from .crs import es_soportado, mensaje_crs_no_soportado
from .settings_dialog import SettingsDialog, get_settings

# Destinos de carga, en el orden del combo. El backend dice cuáles admite cada
# trámite en `pasos_disponibles` (3ª clase solo Construcción, Efectos
# registrales solo Terreno, Asignación NPN solo las mutaciones que numeran).
DESTINOS = (
    ('terreno', 'Terreno'),
    ('asignacion_npn', 'Terreno · Asignación NPN'),
    ('construccion', 'Construcción'),
)


def _es_error_auth(e):
    """¿Es un error que requiere reconfigurar el token?"""
    return getattr(e, 'status', None) == 401


class UploadDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('SmartCube — Publicar shape')
        self.setMinimumWidth(600)
        self.setMinimumHeight(480)
        cfg = get_settings()
        self.client = SmartcubeClient(cfg['backend_url'], cfg['api_token'])
        self.tramites = []

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.tramite_combo = QComboBox()
        self.tramite_combo.currentIndexChanged.connect(self._on_tramite_changed)
        form.addRow('Trámite:', self.tramite_combo)

        self.capa_destino_combo = QComboBox()
        # La actualización cartográfica tiene su propio botón en la barra
        # (`actualizacion_dialog`): es otro flujo, sin trámite ni resolución.
        # Se llena al elegir el trámite (`_poblar_destinos`).
        self.capa_destino_combo.currentIndexChanged.connect(self._on_destino_changed)
        form.addRow('Capa destino:', self.capa_destino_combo)

        self.predio_combo = QComboBox()
        self.predio_combo.currentIndexChanged.connect(self._on_predio_changed)
        form.addRow('Predio:', self.predio_combo)
        self.predio_label_row = form.rowCount() - 1

        self.npn_esperado_label = QLabel('')
        self.npn_esperado_label.setWordWrap(True)
        self.npn_esperado_label.setStyleSheet(
            'color: #1565c0; font-size: 11px; padding: 4px 0;'
        )
        form.addRow('', self.npn_esperado_label)

        self.capa_qgis_combo = QComboBox()
        self._poblar_capas_qgis()
        form.addRow('Capa QGIS a publicar:', self.capa_qgis_combo)

        layout.addLayout(form)

        layout.addWidget(QLabel('Vista previa / mensajes:'))
        self.preview = QTextEdit()
        self.preview.setReadOnly(True)
        self.preview.setMinimumHeight(150)
        layout.addWidget(self.preview)

        btns = QHBoxLayout()
        refresh_btn = QPushButton('Recargar trámites')
        refresh_btn.clicked.connect(self._cargar_tramites)
        btns.addWidget(refresh_btn)
        btns.addStretch()
        cancel_btn = QPushButton('Cerrar')
        cancel_btn.clicked.connect(self.reject)
        btns.addWidget(cancel_btn)
        self.publish_btn = QPushButton('Publicar')
        self.publish_btn.setDefault(True)
        self.publish_btn.clicked.connect(self._publicar)
        btns.addWidget(self.publish_btn)
        layout.addLayout(btns)

        self._cargar_tramites()

    # ---------- carga inicial ----------

    def _cargar_tramites(self):
        self.tramite_combo.clear()
        self.tramites = []
        try:
            self.tramites = self.client.mis_tramites() or []
        except ApiError as e:
            self._log(f'✗ Error cargando trámites: {e}')
            if _es_error_auth(e) and self._reconfigurar_token(motivo=str(e)):
                # Reintenta con el token nuevo.
                self._cargar_tramites()
            return
        for t in self.tramites:
            label = f"{t.get('radicado_numero') or '?'} · {t.get('mutacion_tipo') or '?'} · ({len(t.get('predios', []))} predio/s)"
            self.tramite_combo.addItem(label, t)
        if not self.tramites:
            self._log('No tienes trámites asignados como cargador.')
        else:
            self._log(f'{len(self.tramites)} trámite(s) disponibles.')

    def _reconfigurar_token(self, motivo=''):
        """Abre el diálogo de configuración para que el cargador pegue un
        token nuevo. Devuelve True si guardó cambios (debe reintentar) o False
        si canceló.
        """
        mensaje = (
            'El token API ha sido revocado o ya no es válido.\n\n'
            f'{motivo}\n\n'
            'Genera un token nuevo en SmartCube web (/perfil → Tokens API) '
            'y pégalo en la siguiente ventana.'
        )
        QMessageBox.warning(self, 'SmartCube — Token inválido', mensaje)
        dlg = SettingsDialog(self)
        if dlg.exec_() == QDialog.Accepted:
            # Reconstruir el cliente con la nueva configuración.
            cfg = get_settings()
            self.client = SmartcubeClient(cfg['backend_url'], cfg['api_token'])
            self._log('✓ Token reconfigurado.')
            return True
        self._log('Reconfiguración cancelada. El plugin queda sin acceso hasta que pegues un token válido.')
        return False

    def _poblar_capas_qgis(self):
        self.capa_qgis_combo.clear()
        try:
            for layer in QgsProject.instance().mapLayers().values():
                # solo capas vectoriales
                if hasattr(layer, 'wkbType'):
                    self.capa_qgis_combo.addItem(layer.name(), layer)
        except Exception as e:
            self._log(f'Error listando capas QGIS: {e}')

    # ---------- handlers UI ----------

    def _on_tramite_changed(self, idx):
        self.predio_combo.clear()
        t = self.tramite_combo.currentData()
        if not t:
            self._actualizar_npn_esperado()
            return
        for p in t.get('predios', []):
            # Etiqueta muestra el NPN esperado (que puede ser distinto al matriz
            # en mutaciones que crean predio). Indica con flecha si difiere.
            npn_matriz = p.get('npn') or ''
            npn_esperado = p.get('npn_principal_esperado') or ''
            if npn_esperado and npn_esperado != npn_matriz:
                label = f"{npn_matriz[:30]} → {npn_esperado[:30]} (NUEVO)"
            else:
                label = f"{npn_matriz[:30]}"
            if not p.get('npn_esperado_listo'):
                label += '  ⚠ paso 1 incompleto'
            self.predio_combo.addItem(label, p)
        self._poblar_destinos(t)
        self._on_destino_changed(self.capa_destino_combo.currentIndex())

    def _poblar_destinos(self, t):
        """Ofrece solo los destinos que admite la mutación del trámite.

        Un backend anterior a `pasos_disponibles` por mutación no manda la
        lista: en ese caso se ofrecen todos, como antes.
        """
        previo = self.capa_destino_combo.currentText()
        pasos = (t or {}).get('pasos_disponibles')
        if pasos is None:
            pasos = [clave for clave, _ in DESTINOS]
        self.capa_destino_combo.blockSignals(True)
        self.capa_destino_combo.clear()
        for clave, nombre in DESTINOS:
            if clave in pasos:
                self.capa_destino_combo.addItem(nombre, clave)
        idx = self.capa_destino_combo.findText(previo)
        self.capa_destino_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.capa_destino_combo.blockSignals(False)
        if t and not pasos:
            self._log('Esta mutación no modifica nada físico: no admite cargas de shape.')

    def _on_destino_changed(self, idx):
        destino = self.capa_destino_combo.currentText()
        # Predio visible solo en 'Terreno' normal. En 'Terreno · Asignación NPN'
        # el matriz se toma del trámite (no se elige predio); en 'Construcción'
        # tampoco aplica.
        es_terreno = destino == 'Terreno'
        self.predio_combo.setVisible(es_terreno)
        self.npn_esperado_label.setVisible(es_terreno)
        self._actualizar_npn_esperado()

    def _on_predio_changed(self, idx):
        self._actualizar_npn_esperado()

    def _actualizar_npn_esperado(self):
        p = self.predio_combo.currentData()
        if not p:
            self.npn_esperado_label.setText('')
            return
        if not p.get('npn_esperado_listo'):
            aviso = p.get('aviso') or 'NPN esperado aún no disponible.'
            self.npn_esperado_label.setText(f'⚠ {aviso}')
            self.npn_esperado_label.setStyleSheet(
                'color: #c62828; font-size: 11px; padding: 4px 0;'
            )
            return
        npn = p.get('npn_principal_esperado') or ''
        es_nuevo = npn and npn != (p.get('npn') or '')
        sufijo = '  (NPN del predio NUEVO asignado en Paso 1)' if es_nuevo else ''
        self.npn_esperado_label.setText(
            f'NPN a rotular en el polígono principal del shape:\n{npn}{sufijo}'
        )
        self.npn_esperado_label.setStyleSheet(
            'color: #1565c0; font-size: 11px; padding: 4px 0; font-family: monospace;'
        )

    # ---------- publicación ----------

    def _publicar(self):
        destino = self.capa_destino_combo.currentText()
        t = self.tramite_combo.currentData()
        if not t:
            self._log('Selecciona un trámite.')
            return
        if not destino:
            self._log('La mutación de este trámite no admite cargas de shape.')
            return
        capa = self.capa_qgis_combo.currentData()
        if not capa:
            self._log('Selecciona una capa QGIS a publicar.')
            return

        # El backend deduce el CRS del .prj y esa deducción falla en abierto
        # hacia 4326: una capa en metros sin .prj legible entra al borrador
        # etiquetada como grados y revienta al commitear. Se corta aquí.
        authid = capa.crs().authid() if capa.crs().isValid() else ''
        if not es_soportado(authid):
            mensaje = mensaje_crs_no_soportado(authid)
            self._log(f'✗ Sistema de referencia no admitido: {authid or "sin definir"}')
            QMessageBox.warning(self, 'SmartCube', mensaje)
            return

        # Crear .zip temporal con la capa exportada como Shapefile
        try:
            zip_path = self._exportar_capa_a_zip(capa)
        except Exception as e:
            self._log(f'✗ Error exportando capa a Shapefile: {e}')
            return

        self._log(
            f'Publicando {capa.name()} → {destino} (trámite {t["tramite_t_id"]})…'
        )
        try:
            if destino == 'Terreno':
                p = self.predio_combo.currentData()
                if not p:
                    self._log('Selecciona un predio.')
                    return
                resp = self.client.upload_terreno(
                    t['tramite_t_id'], p['predio_t_id'], zip_path,
                )
                self._log(
                    f'✓ Carga creada (id={resp["carga_t_id"]}). '
                    f'{resp["count_features"]} features '
                    f'({resp.get("count_colindantes", 0)} colindantes).'
                )
                if resp.get('warnings'):
                    self._log('Warnings: ' + '; '.join(resp['warnings']))
            elif destino == 'Terreno · Asignación NPN':
                resp = self.client.upload_terreno_segregacion(
                    t['tramite_t_id'], zip_path,
                )
                # El endpoint responde de DOS formas y hay que leer las dos. Si
                # los predios del trámite ya están materializados no crea ninguna
                # carga: actualiza en sitio la geometría de cada lote y devuelve
                # `{'modo': 'actualizacion', ...}`, sin `carga_t_id`. Asumir la
                # primera forma reventaba con KeyError DESPUÉS de que el backend
                # ya había aplicado los cambios, y se perdía el resumen —que es
                # justo lo que dice si el shape emparejó o no.
                if resp.get('modo') == 'actualizacion':
                    sin_match = resp.get('sin_match') or []
                    self._log(
                        f'✓ Geometría actualizada en sitio: '
                        f'{resp.get("actualizados", 0)} predio(s), '
                        f'{resp.get("colindantes", 0)} colindante(s).'
                    )
                    if sin_match:
                        self._log(
                            'Sin emparejar (NPN que no es del trámite ni un '
                            'predio existente): ' + ', '.join(str(s) for s in sin_match)
                        )
                    if not resp.get('actualizados'):
                        self._log(
                            'Ningún polígono emparejó con un predio del trámite. '
                            'Los predios ya están numerados, así que el shape '
                            'debe traer cada polígono ROTULADO con su NPN.'
                        )
                else:
                    self._log(
                        f'✓ Carga de segregación creada (id={resp.get("carga_t_id")}). '
                        f'{resp.get("count_nuevos", 0)} predios nuevos por numerar '
                        f'(matriz {resp.get("principal_npn", "?")}).'
                    )
            else:
                resp = self.client.upload_construccion(t['tramite_t_id'], zip_path)
                self._log(
                    f'✓ Carga creada (id={resp["carga_t_id"]}). '
                    f'{resp["count_features"]} features '
                    f'({len(resp.get("identificadores_uc", []))} UC).'
                )
                if resp.get('warnings'):
                    self._log('Warnings: ' + '; '.join(resp['warnings']))
            QMessageBox.information(self, 'SmartCube', 'Shape publicado correctamente.')
        except ApiError as e:
            self._log(f'✗ {e} (status={e.status})')
            if _es_error_auth(e):
                if self._reconfigurar_token(motivo=str(e)):
                    # Reintenta la publicación con el token nuevo.
                    # Nota: el ZIP temporal ya fue limpiado en el finally;
                    # le pedimos al usuario que vuelva a pulsar Publicar.
                    QMessageBox.information(
                        self, 'SmartCube',
                        'Token reconfigurado. Pulsa "Publicar" de nuevo para reintentar.',
                    )
            else:
                QMessageBox.warning(self, 'SmartCube', f'No se pudo publicar:\n{e}')
        finally:
            # Limpiar temp
            try:
                os.remove(zip_path)
                os.rmdir(os.path.dirname(zip_path))
            except Exception:
                pass

    def _exportar_capa_a_zip(self, capa):
        """Exporta la capa QGIS a un Shapefile temporal y lo zippea."""
        tmpdir = tempfile.mkdtemp(prefix='smartcube_')
        shp_path = os.path.join(tmpdir, 'capa.shp')

        # La capa se exporta en su CRS nativo, que `_publicar` ya validó como
        # 4326 o 9377. (Antes había aquí un `target_crs` que se calculaba y no
        # se usaba: `writeAsVectorFormatV3` no recibe CRS de destino, así que
        # nunca reproyectó nada.)
        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = 'ESRI Shapefile'
        options.fileEncoding = 'UTF-8'

        writer_err = QgsVectorFileWriter.writeAsVectorFormatV3(
            capa, shp_path, QgsProject.instance().transformContext(), options,
        )
        if isinstance(writer_err, tuple):
            err_code = writer_err[0]
        else:
            err_code = writer_err
        if err_code != QgsVectorFileWriter.NoError:
            raise RuntimeError(f'Error escribiendo Shapefile (code={err_code})')

        # Zippear .shp/.dbf/.shx/.prj/.cpg
        zip_path = os.path.join(tmpdir, 'capa.zip')
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for ext in ('shp', 'dbf', 'shx', 'prj', 'cpg'):
                p = os.path.join(tmpdir, f'capa.{ext}')
                if os.path.exists(p):
                    zf.write(p, f'capa.{ext}')
        return zip_path

    def _log(self, msg):
        self.preview.append(msg)
