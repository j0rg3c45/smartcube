"""SmartCube Uploader — Plugin QGIS para publicar shapes a trámites SmartCube."""


def classFactory(iface):
    from .plugin import SmartcubeUploaderPlugin
    return SmartcubeUploaderPlugin(iface)
