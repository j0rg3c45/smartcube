"""Diálogo de Actualización cartográfica.

Botón propio y no una opción del desplegable de «Publicar shape»: es otro
flujo. Aquí no hay trámite, no hay mutación y no habrá resolución — se corrige
la geometría de predios YA INSCRITOS y un admin lo aprueba. Mezclarlo con la
publicación a trámites escondía el camino nuevo dentro de un combo.

El shape trae los NPN rotulados; el módulo web los resuelve, comprueba si cada
predio se puede corregir y deja la carga pendiente de revisión.
"""

import os
import tempfile
import zipfile

from qgis.core import QgsProject, QgsVectorFileWriter
from qgis.PyQt.QtWidgets import (
    QComboBox, QDialog, QFormLayout, QHBoxLayout, QLabel, QMessageBox,
    QPlainTextEdit, QPushButton, QTextEdit, QVBoxLayout,
)

from .api_client import ApiError, SmartcubeClient
from .crs import es_soportado, mensaje_crs_no_soportado
from .settings_dialog import SettingsDialog, get_settings

# Etiqueta visible → valor que espera el backend. Aquí crecen las capas nuevas.
CAPAS = (
    ('Terreno', 'terreno'),
    ('Unidades de construcción', 'unidad_construccion'),
)


class ActualizacionDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('SmartCube — Actualización cartográfica')
        self.setMinimumWidth(620)
        self.setMinimumHeight(460)
        cfg = get_settings()
        self.client = SmartcubeClient(cfg['backend_url'], cfg['api_token'])

        layout = QVBoxLayout(self)

        cabecera = QLabel(
            'Corrige la geometría de predios <b>ya inscritos</b>. No genera '
            'trámite ni resolución: la carga queda pendiente de que un '
            'administrador la apruebe desde la aplicación web.'
        )
        cabecera.setWordWrap(True)
        cabecera.setStyleSheet('color: #444; font-size: 11px; padding: 4px 0 8px 0;')
        layout.addWidget(cabecera)

        form = QFormLayout()

        self.capa_destino_combo = QComboBox()
        for etiqueta, _valor in CAPAS:
            self.capa_destino_combo.addItem(etiqueta)
        form.addRow('Capa a actualizar:', self.capa_destino_combo)

        self.capa_qgis_combo = QComboBox()
        self._poblar_capas_qgis()
        form.addRow('Capa QGIS a publicar:', self.capa_qgis_combo)

        # El motivo es obligatorio: sin resolución que respalde el cambio, es lo
        # único que lo explicará cuando alguien mire el predio dentro de dos años.
        self.motivo_input = QPlainTextEdit()
        self.motivo_input.setPlaceholderText(
            'Por qué se corrige. Ej.: ajuste de linderos por vuelo '
            'fotogramétrico 2026, según acta del 12/03/2026.'
        )
        self.motivo_input.setFixedHeight(70)
        form.addRow('Motivo:', self.motivo_input)

        layout.addLayout(form)

        aviso = QLabel(
            'El shape debe traer cada polígono rotulado con su <b>NPN</b>. Los '
            'predios con un trámite abierto o con historia registral no se '
            'pueden corregir por aquí; se te dirá cuáles.'
        )
        aviso.setWordWrap(True)
        aviso.setStyleSheet('color: #8a6d3b; font-size: 11px; padding: 4px 0;')
        layout.addWidget(aviso)

        layout.addWidget(QLabel('Mensajes:'))
        self.preview = QTextEdit()
        self.preview.setReadOnly(True)
        self.preview.setMinimumHeight(140)
        layout.addWidget(self.preview)

        btns = QHBoxLayout()
        refresh_btn = QPushButton('Recargar capas')
        refresh_btn.clicked.connect(self._poblar_capas_qgis)
        btns.addWidget(refresh_btn)
        btns.addStretch()
        cerrar_btn = QPushButton('Cerrar')
        cerrar_btn.clicked.connect(self.reject)
        btns.addWidget(cerrar_btn)
        self.publish_btn = QPushButton('Publicar')
        self.publish_btn.setDefault(True)
        self.publish_btn.clicked.connect(self._publicar)
        btns.addWidget(self.publish_btn)
        layout.addLayout(btns)

    # ---------- utilidades ----------

    def _log(self, texto):
        self.preview.append(texto)

    def _poblar_capas_qgis(self):
        self.capa_qgis_combo.clear()
        try:
            for layer in QgsProject.instance().mapLayers().values():
                if hasattr(layer, 'wkbType'):
                    self.capa_qgis_combo.addItem(layer.name(), layer)
        except Exception as e:
            self._log(f'Error listando capas QGIS: {e}')

    def _exportar_capa_a_zip(self, capa):
        """Exporta la capa a un Shapefile temporal y lo zippea (en su CRS nativo)."""
        tmpdir = tempfile.mkdtemp(prefix='smartcube_carto_')
        shp_path = os.path.join(tmpdir, 'capa.shp')

        options = QgsVectorFileWriter.SaveVectorOptions()
        options.driverName = 'ESRI Shapefile'
        options.fileEncoding = 'UTF-8'

        writer_err = QgsVectorFileWriter.writeAsVectorFormatV3(
            capa, shp_path, QgsProject.instance().transformContext(), options,
        )
        err_code = writer_err[0] if isinstance(writer_err, tuple) else writer_err
        if err_code != QgsVectorFileWriter.NoError:
            raise RuntimeError(f'Error escribiendo Shapefile (code={err_code})')

        zip_path = os.path.join(tmpdir, 'capa.zip')
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
            for ext in ('shp', 'dbf', 'shx', 'prj', 'cpg'):
                p = os.path.join(tmpdir, f'capa.{ext}')
                if os.path.exists(p):
                    zf.write(p, f'capa.{ext}')
        return zip_path

    # ---------- publicación ----------

    def _publicar(self):
        capa = self.capa_qgis_combo.currentData()
        if not capa:
            self._log('Selecciona una capa QGIS a publicar.')
            return

        motivo = self.motivo_input.toPlainText().strip()
        if not motivo:
            self._log('✗ Falta el motivo.')
            QMessageBox.warning(
                self, 'SmartCube',
                'La actualización cartográfica exige un motivo. No genera '
                'resolución, así que ese texto es todo lo que quedará para '
                'explicar por qué cambió la geometría.',
            )
            return

        # El backend deduce el CRS del .prj y esa deducción falla en abierto
        # hacia 4326: una capa en metros sin .prj legible entraría etiquetada
        # como grados. Se corta aquí.
        authid = capa.crs().authid() if capa.crs().isValid() else ''
        if not es_soportado(authid):
            self._log(f'✗ Sistema de referencia no admitido: {authid or "sin definir"}')
            QMessageBox.warning(self, 'SmartCube', mensaje_crs_no_soportado(authid))
            return

        try:
            zip_path = self._exportar_capa_a_zip(capa)
        except Exception as e:
            self._log(f'✗ Error exportando capa a Shapefile: {e}')
            return

        etiqueta = self.capa_destino_combo.currentText()
        valor_capa = dict(CAPAS)[etiqueta]
        self._log(f'Publicando {capa.name()} → {etiqueta}…')
        try:
            resp = self.client.upload_actualizacion_cartografia(
                zip_path, capa=valor_capa, motivo=motivo,
            )
            self._log('✓ ' + (resp.get('detail') or 'Carga creada.'))
            self._log(
                'Queda pendiente de que un administrador la revise y la '
                'apruebe en la aplicación web.'
            )
            if resp.get('bloqueados'):
                self._log(
                    f'⚠ {resp["bloqueados"]} geometría(s) no se podrán aplicar. '
                    'El módulo web indica el motivo de cada una (trámite '
                    'abierto, historia registral o NPN inexistente).'
                )
            QMessageBox.information(
                self, 'SmartCube',
                'Carga publicada. Un administrador debe aprobarla para que la '
                'geometría se actualice.',
            )
        except ApiError as e:
            self._log(f'✗ {e} (status={e.status})')
            if getattr(e, 'status', None) == 401:
                QMessageBox.warning(
                    self, 'SmartCube — Token inválido',
                    'El token API ya no es válido. Genera uno nuevo en '
                    'SmartCube web (/perfil → Tokens API).',
                )
                dlg = SettingsDialog(self)
                if dlg.exec_() == QDialog.Accepted:
                    cfg = get_settings()
                    self.client = SmartcubeClient(
                        cfg['backend_url'], cfg['api_token'],
                    )
                    self._log('✓ Token reconfigurado. Pulsa «Publicar» de nuevo.')
            else:
                QMessageBox.warning(self, 'SmartCube', str(e))
        except Exception as e:
            self._log(f'✗ Error inesperado: {e}')
        finally:
            try:
                os.remove(zip_path)
            except Exception:
                pass
