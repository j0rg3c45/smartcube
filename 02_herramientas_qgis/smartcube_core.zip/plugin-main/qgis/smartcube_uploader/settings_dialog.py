"""Diálogo de configuración del plugin."""

from qgis.PyQt.QtCore import QSettings
from qgis.PyQt.QtWidgets import (
    QDialog, QLabel, QLineEdit, QMessageBox, QPushButton, QVBoxLayout, QHBoxLayout,
)

from .api_client import ApiError, SmartcubeClient

SETTINGS_PREFIX = 'smartcube/'


def get_settings():
    s = QSettings()
    return {
        'backend_url': s.value(SETTINGS_PREFIX + 'backend_url', 'http://localhost:7000', type=str),
        'api_token': s.value(SETTINGS_PREFIX + 'api_token', '', type=str),
    }


def save_settings(backend_url, api_token):
    s = QSettings()
    s.setValue(SETTINGS_PREFIX + 'backend_url', backend_url)
    s.setValue(SETTINGS_PREFIX + 'api_token', api_token)


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('SmartCube — Configuración')
        self.setMinimumWidth(500)
        cfg = get_settings()

        layout = QVBoxLayout(self)

        layout.addWidget(QLabel('URL del backend SmartCube:'))
        self.url_input = QLineEdit(cfg['backend_url'])
        self.url_input.setPlaceholderText('http://localhost:7000')
        layout.addWidget(self.url_input)

        layout.addWidget(QLabel('API Token (genera uno desde /perfil):'))
        self.token_input = QLineEdit(cfg['api_token'])
        self.token_input.setPlaceholderText('smc_...')
        self.token_input.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.token_input)

        show_btn = QPushButton('Mostrar / Ocultar token')
        show_btn.clicked.connect(self._toggle_token)
        layout.addWidget(show_btn)

        self.status_label = QLabel('')
        self.status_label.setStyleSheet('color: #666; font-size: 11px;')
        layout.addWidget(self.status_label)

        btns = QHBoxLayout()
        test_btn = QPushButton('Probar conexión')
        test_btn.clicked.connect(self._test_connection)
        btns.addWidget(test_btn)
        btns.addStretch()
        cancel_btn = QPushButton('Cancelar')
        cancel_btn.clicked.connect(self.reject)
        btns.addWidget(cancel_btn)
        save_btn = QPushButton('Guardar')
        save_btn.setDefault(True)
        save_btn.clicked.connect(self._save)
        btns.addWidget(save_btn)
        layout.addLayout(btns)

    def _toggle_token(self):
        mode = self.token_input.echoMode()
        self.token_input.setEchoMode(
            QLineEdit.Normal if mode == QLineEdit.Password else QLineEdit.Password
        )

    def _test_connection(self):
        url = self.url_input.text().strip()
        token = self.token_input.text().strip()
        if not url or not token:
            self.status_label.setText('Completa URL y token primero.')
            return
        client = SmartcubeClient(url, token)
        try:
            data = client.test_connection()
            count = len(data) if isinstance(data, list) else 0
            self.status_label.setText(
                f'✓ Conexión exitosa. {count} trámite(s) accesibles.'
            )
            self.status_label.setStyleSheet('color: green; font-size: 11px;')
        except ApiError as e:
            self.status_label.setText(f'✗ Error: {e} (status={e.status})')
            self.status_label.setStyleSheet('color: red; font-size: 11px;')

    def _save(self):
        url = self.url_input.text().strip()
        token = self.token_input.text().strip()
        if not url:
            QMessageBox.warning(self, 'Error', 'La URL no puede estar vacía.')
            return
        save_settings(url, token)
        self.accept()
