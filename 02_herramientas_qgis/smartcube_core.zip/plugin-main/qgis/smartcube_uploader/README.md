﻿# SmartCube Uploader — Plugin QGIS

Plugin de QGIS para publicar shapefiles de terreno y unidades de construcción a trámites SmartCube directamente desde tu sesión de QGIS.

## Instalación

1. Descarga el archivo `smartcube_uploader.zip` (o constrúyelo con `bash qgis/build.sh`).
2. En QGIS: **Plugins → Administrar e instalar plugins → Instalar desde ZIP**.
3. Selecciona el `.zip` descargado. QGIS lo instalará automáticamente.
4. Activa el plugin si no se activó solo: **Plugins → Administrar → Instalados → SmartCube Uploader**.

## Configuración

1. Genera un API token en SmartCube web: `/perfil` → sección **Tokens API** → **Crear token** → copia el `smc_xxx…` (se muestra una sola vez).
2. En QGIS: menú **SmartCube → Configuración**.
3. Pega la URL del backend (por defecto `http://localhost:7000`) y el token.
4. Pulsa **Probar conexión** — si tu rol y token son correctos, verás los trámites asignados.
5. Guarda.

## Uso

1. Abre la capa vectorial de tu shapefile en QGIS (Capa → Añadir capa vectorial).
2. Verifica que cada feature trae el campo `NPN` (terreno) o `NPN` + `identificador` (UC).
3. Menú **SmartCube → Publicar shape…**.
4. En el diálogo:
   - **Trámite**: lista de trámites donde el analista te invitó como cargador.
   - **Capa destino**: Terreno o Construcción.
   - **Predio**: visible solo para Terreno. Selecciona el predio cuyo NPN coincide con el del shape.
   - **Capa QGIS**: la capa abierta a subir.
5. **Publicar**.

El plugin empaquetará la capa como Shapefile.zip y la enviará al backend. El analista verá el shape en el wizard del trámite (Paso 3 o Paso 4) la próxima vez que abra el paso.

## Requisitos

- QGIS 3.22 o superior.
- Conexión HTTPS al backend SmartCube.
- Rol `user-cargador-shape` activo en tu usuario.
- Token API válido (no revocado).

## Errores comunes

| Error | Causa probable |
|-------|----------------|
| `401 Token inválido` | El token no existe o fue revocado. Genera uno nuevo. |
| `403 Forbidden` | El analista no te ha invitado al trámite. Pídele que te invite desde `/asignacion`. |
| `400 NPN no coincide` | El shape no trae un polígono con el NPN del predio seleccionado. Revisa la columna NPN del DBF. |
| `409 Trámite cerrado` | El trámite ya fue aprobado o rechazado. Solicita uno nuevo. |
| Archivo supera 20 MB | Tu shape es muy pesado. Simplifica geometría o filtra features. |

## Desarrollo

Esto es un plugin estándar de QGIS en Python puro (stdlib + PyQt5 + qgis.core). Para iterar:

1. Copia o symlinkea `qgis/smartcube_uploader/` a tu carpeta de plugins de QGIS:
   - **Windows**: `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\smartcube_uploader\`
   - **Linux/Mac**: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/smartcube_uploader/`
2. Reinicia QGIS o usa el plugin **Plugin Reloader** para recargar sin reiniciar.

## Licencia

Interno SmartCube.
