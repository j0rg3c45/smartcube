"""Diálogo para cargar capas catastrales de SmartCube como memory layers en QGIS."""

import json
import os
import tempfile

from qgis.core import (
    QgsCategorizedSymbolRenderer,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFillSymbol,
    QgsLineSymbol,
    QgsProject,
    QgsRendererCategory,
    QgsVectorLayer,
)
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QRadioButton,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from .api_client import ApiError, SmartcubeClient
from .settings_dialog import SettingsDialog, get_settings


# Slug del endpoint, etiqueta, requiere bbox/npn, etc.
CAPAS_DEF = [
    ('terrenos', 'Terrenos'),
    ('unidades', 'Unidades de construcción'),
    ('terrenos_borrador', 'Terrenos (Borrador)'),
    ('unidades_borrador', 'Unidades (Borrador)'),
    ('manzanas', 'Manzanas'),
    ('sectores', 'Sectores'),
    ('veredas', 'Veredas'),
    ('barrios', 'Barrios'),
    ('colindantes', 'Colindantes'),
]

# Capas que pegan a un endpoint distinto de su slug, con parámetros fijos.
ENDPOINT_BORRADOR = {
    'terrenos_borrador': ('terrenos', {'estado': 'borrador'}),
    'unidades_borrador': ('unidades', {'estado': 'borrador'}),
}


def _es_error_auth(e):
    return getattr(e, 'status', None) == 401


class CartografiaDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle('SmartCube — Cargar capas catastrales')
        self.setMinimumWidth(620)
        self.setMinimumHeight(560)
        cfg = get_settings()
        self.client = SmartcubeClient(cfg['backend_url'], cfg['api_token'])
        self.tramites = []

        layout = QVBoxLayout(self)

        # ---------- Origen del filtro ----------
        origen_box = QGroupBox('Origen del filtro')
        origen_layout = QFormLayout(origen_box)

        self.origen_group = QButtonGroup(self)

        self.rb_bbox = QRadioButton('Vista actual del mapa (bbox)')
        self.rb_bbox.setChecked(True)
        self.origen_group.addButton(self.rb_bbox)
        origen_layout.addRow(self.rb_bbox)

        # Trámite
        tram_row = QHBoxLayout()
        self.rb_tramite = QRadioButton('Mi trámite:')
        self.origen_group.addButton(self.rb_tramite)
        self.tramite_combo = QComboBox()
        self.tramite_combo.setMinimumWidth(380)
        tram_row.addWidget(self.rb_tramite)
        tram_row.addWidget(self.tramite_combo, 1)
        tram_wrap = QWidget()
        tram_wrap.setLayout(tram_row)
        origen_layout.addRow(tram_wrap)

        # NPN
        npn_row = QHBoxLayout()
        self.rb_npn = QRadioButton('NPN específico:')
        self.origen_group.addButton(self.rb_npn)
        self.npn_input = QLineEdit()
        self.npn_input.setPlaceholderText('30 caracteres')
        self.npn_input.setMaxLength(30)
        npn_row.addWidget(self.rb_npn)
        npn_row.addWidget(self.npn_input, 1)
        npn_wrap = QWidget()
        npn_wrap.setLayout(npn_row)
        origen_layout.addRow(npn_wrap)

        # Barrio
        barrio_row = QHBoxLayout()
        self.rb_barrio = QRadioButton('Barrio (id):')
        self.origen_group.addButton(self.rb_barrio)
        self.barrio_input = QLineEdit()
        self.barrio_input.setPlaceholderText('Identificador numérico del barrio')
        barrio_row.addWidget(self.rb_barrio)
        barrio_row.addWidget(self.barrio_input, 1)
        barrio_wrap = QWidget()
        barrio_wrap.setLayout(barrio_row)
        origen_layout.addRow(barrio_wrap)

        # Sector
        sector_row = QHBoxLayout()
        self.rb_sector = QRadioButton('Sector (id):')
        self.origen_group.addButton(self.rb_sector)
        self.sector_input = QLineEdit()
        self.sector_input.setPlaceholderText('Identificador numérico del sector')
        sector_row.addWidget(self.rb_sector)
        sector_row.addWidget(self.sector_input, 1)
        sector_wrap = QWidget()
        sector_wrap.setLayout(sector_row)
        origen_layout.addRow(sector_wrap)

        # Manzana
        manzana_row = QHBoxLayout()
        self.rb_manzana = QRadioButton('Manzana (id):')
        self.origen_group.addButton(self.rb_manzana)
        self.manzana_input = QLineEdit()
        self.manzana_input.setPlaceholderText('Identificador numérico de la manzana')
        manzana_row.addWidget(self.rb_manzana)
        manzana_row.addWidget(self.manzana_input, 1)
        manzana_wrap = QWidget()
        manzana_wrap.setLayout(manzana_row)
        origen_layout.addRow(manzana_wrap)

        layout.addWidget(origen_box)

        # ---------- Capas a cargar ----------
        capas_box = QGroupBox('Capas a cargar')
        capas_grid = QGridLayout(capas_box)
        self.capa_checks = {}
        # Disposición 2 columnas
        for idx, (slug, label) in enumerate(CAPAS_DEF):
            cb = QCheckBox(label)
            if slug in ('terrenos', 'unidades'):
                cb.setChecked(True)
            row = idx // 2
            col = idx % 2
            capas_grid.addWidget(cb, row, col)
            self.capa_checks[slug] = cb
        layout.addWidget(capas_box)

        # Conectar señales que dependen del origen para habilitar/deshabilitar capas
        self.origen_group.buttonToggled.connect(self._on_origen_changed)

        # ---------- Logs ----------
        layout.addWidget(QLabel('Vista previa / mensajes:'))
        self.preview = QTextEdit()
        self.preview.setReadOnly(True)
        self.preview.setMinimumHeight(140)
        layout.addWidget(self.preview)

        # ---------- Botones ----------
        btns = QHBoxLayout()
        refresh_btn = QPushButton('Recargar trámites')
        refresh_btn.clicked.connect(self._cargar_tramites)
        btns.addWidget(refresh_btn)
        btns.addStretch()
        cerrar_btn = QPushButton('Cerrar')
        cerrar_btn.clicked.connect(self.reject)
        btns.addWidget(cerrar_btn)
        self.cargar_btn = QPushButton('Cargar capas')
        self.cargar_btn.setDefault(True)
        self.cargar_btn.clicked.connect(self._cargar_capas)
        btns.addWidget(self.cargar_btn)
        layout.addLayout(btns)

        # Estado inicial
        self._cargar_tramites()
        self._on_origen_changed()

    # ---------- carga inicial ----------

    def _cargar_tramites(self):
        self.tramite_combo.clear()
        self.tramites = []
        try:
            self.tramites = self.client.mis_tramites_para_filtro() or []
        except ApiError as e:
            self._log(f'✗ Error cargando trámites: {e}')
            if _es_error_auth(e) and self._reconfigurar_token(motivo=str(e)):
                self._cargar_tramites()
            return
        for t in self.tramites:
            predios = t.get('predios', []) or []
            npn_principal = ''
            if predios:
                npn_principal = (
                    predios[0].get('npn_principal_esperado')
                    or predios[0].get('npn')
                    or ''
                )
            label = (
                f"{t.get('radicado_numero') or '?'} · "
                f"{t.get('mutacion_tipo') or '?'} · "
                f"NPN {npn_principal[:30] if npn_principal else 's/n'}"
            )
            self.tramite_combo.addItem(label, t)
        if not self.tramites:
            self._log('No tienes trámites asignados como cargador.')
        else:
            self._log(f'{len(self.tramites)} trámite(s) disponibles.')

    def _reconfigurar_token(self, motivo=''):
        mensaje = (
            'El token API ha sido revocado o ya no es válido.\n\n'
            f'{motivo}\n\n'
            'Genera un token nuevo en SmartCube web (/perfil → Tokens API) '
            'y pégalo en la siguiente ventana.'
        )
        QMessageBox.warning(self, 'SmartCube — Token inválido', mensaje)
        dlg = SettingsDialog(self)
        if dlg.exec_() == QDialog.Accepted:
            cfg = get_settings()
            self.client = SmartcubeClient(cfg['backend_url'], cfg['api_token'])
            self._log('✓ Token reconfigurado.')
            return True
        self._log('Reconfiguración cancelada. El plugin queda sin acceso hasta que pegues un token válido.')
        return False

    # ---------- handlers ----------

    def _on_origen_changed(self, *args):
        # Colindantes necesita un predio de referencia: NPN específico, o los
        # predios de Mi trámite (vecinos de todos ellos, sin los del trámite).
        con_referencia = self.rb_npn.isChecked() or self.rb_tramite.isChecked()
        cb_col = self.capa_checks.get('colindantes')
        if cb_col is not None:
            cb_col.setEnabled(con_referencia)
            if not con_referencia:
                cb_col.setChecked(False)
                cb_col.setToolTip(
                    'Solo disponible cuando el origen del filtro es Mi trámite '
                    'o NPN específico.'
                )
            else:
                cb_col.setToolTip('')

        # Capas de Borrador solo con filtro de área (bbox/barrio/sector/manzana).
        es_area = (
            self.rb_bbox.isChecked() or self.rb_barrio.isChecked()
            or self.rb_sector.isChecked() or self.rb_manzana.isChecked()
        )
        for slug in ('terrenos_borrador', 'unidades_borrador'):
            cb = self.capa_checks.get(slug)
            if cb is None:
                continue
            cb.setEnabled(es_area)
            if not es_area:
                cb.setChecked(False)
                cb.setToolTip('Solo disponible con filtro de área (bbox/barrio/sector/manzana).')
            else:
                cb.setToolTip('')

    # ---------- cálculo de filtros ----------

    def _calcular_filtros(self):
        """Devuelve dict de filtros listos para query string.

        Solo incluye el filtro correspondiente al radio button seleccionado.
        """
        filtros = {}
        if self.rb_bbox.isChecked():
            bbox = self._bbox_canvas_4326()
            if not bbox:
                raise RuntimeError('No se pudo determinar el bbox actual del canvas.')
            filtros['bbox'] = bbox
        elif self.rb_tramite.isChecked():
            t = self.tramite_combo.currentData()
            if not t:
                raise RuntimeError('Selecciona un trámite.')
            filtros['tramite'] = t.get('tramite_t_id')
        elif self.rb_npn.isChecked():
            npn = (self.npn_input.text() or '').strip()
            if not npn:
                raise RuntimeError('Ingresa el NPN.')
            filtros['npn'] = npn
        elif self.rb_barrio.isChecked():
            val = (self.barrio_input.text() or '').strip()
            if not val:
                raise RuntimeError('Ingresa el id del barrio.')
            filtros['barrio'] = val
        elif self.rb_sector.isChecked():
            val = (self.sector_input.text() or '').strip()
            if not val:
                raise RuntimeError('Ingresa el id del sector.')
            filtros['sector'] = val
        elif self.rb_manzana.isChecked():
            val = (self.manzana_input.text() or '').strip()
            if not val:
                raise RuntimeError('Ingresa el id de la manzana.')
            filtros['manzana'] = val
        return filtros

    def _bbox_canvas_4326(self):
        try:
            canvas = self.iface.mapCanvas()
            extent = canvas.extent()
            src_crs = canvas.mapSettings().destinationCrs()
            target_crs = QgsCoordinateReferenceSystem('EPSG:4326')
            if src_crs.isValid() and src_crs.authid() != 'EPSG:4326':
                xform = QgsCoordinateTransform(src_crs, target_crs, QgsProject.instance())
                extent = xform.transformBoundingBox(extent)
            return f'{extent.xMinimum()},{extent.yMinimum()},{extent.xMaximum()},{extent.yMaximum()}'
        except Exception as e:
            self._log(f'Error obteniendo bbox del canvas: {e}')
            return None

    # ---------- carga ----------

    def _cargar_capas(self):
        try:
            filtros_base = self._calcular_filtros()
        except RuntimeError as e:
            QMessageBox.warning(self, 'SmartCube', str(e))
            self._log(f'✗ {e}')
            return

        seleccionadas = [(s, lbl) for s, lbl in CAPAS_DEF if self.capa_checks[s].isChecked()]
        if not seleccionadas:
            QMessageBox.information(self, 'SmartCube', 'Selecciona al menos una capa.')
            return

        self.cargar_btn.setEnabled(False)
        try:
            for slug, label in seleccionadas:
                filtros = self._adaptar_filtros_para_capa(slug, filtros_base)
                if filtros is None:
                    self._log(f'  {label}: filtro no aplicable; se omite.')
                    continue
                endpoint, params_extra = ENDPOINT_BORRADOR.get(slug, (slug, {}))
                filtros = {**filtros, **params_extra}
                try:
                    geojson = self.client.cargar_capa(endpoint, filtros)
                except ApiError as e:
                    self._log(f'✗ {label}: {e}')
                    if _es_error_auth(e):
                        if self._reconfigurar_token(motivo=str(e)):
                            QMessageBox.information(
                                self, 'SmartCube',
                                'Token reconfigurado. Pulsa "Cargar capas" de nuevo para reintentar.',
                            )
                        return
                    continue
                if not geojson or not geojson.get('features'):
                    self._log(f'  {label}: sin features.')
                    continue
                self._remover_capa_existente(label)
                layer = self._crear_memory_layer(slug, label, geojson)
                if layer is None or not layer.isValid():
                    self._log(f'✗ {label}: no se pudo crear la capa de memoria.')
                    continue
                self._aplicar_simbologia(slug, layer)
                QgsProject.instance().addMapLayer(layer)
                self._log(f'✓ {label}: {len(geojson["features"])} features cargados.')
        finally:
            self.cargar_btn.setEnabled(True)

    def _adaptar_filtros_para_capa(self, slug, filtros_base):
        """Adapta los filtros para la capa según los parámetros que acepta.

        Si la capa requiere un filtro que no está disponible (p.ej. colindantes
        requiere npn o tramite), devuelve None.
        """
        # Tabla de parámetros aceptados por slug
        aceptados = {
            'terrenos': {'bbox', 'npn', 'tramite', 'barrio', 'sector', 'manzana'},
            'unidades': {'bbox', 'npn', 'tramite', 'barrio', 'sector', 'manzana'},
            'terrenos_borrador': {'bbox', 'barrio', 'sector', 'manzana'},
            'unidades_borrador': {'bbox', 'barrio', 'sector', 'manzana'},
            'manzanas': {'bbox', 'sector', 'barrio'},
            'sectores': {'bbox'},
            'veredas':  {'bbox'},
            'barrios':  {'bbox', 'sector'},
            'colindantes': {'npn', 'tramite'},
        }
        permitidos = aceptados.get(slug, set())
        filtros = {k: v for k, v in filtros_base.items() if k in permitidos}
        # Validación: la capa debe tener al menos un filtro acepta-do entre lo solicitado.
        if not filtros:
            # Caso especial: colindantes requiere NPN o trámite.
            if slug == 'colindantes':
                return None
            # Para las demás, si no hay match (p.ej. el usuario eligió "barrio"
            # pero la capa solo acepta bbox), no podemos consultar.
            return None
        return filtros

    def _remover_capa_existente(self, label):
        nombre = f'SmartCube · {label}'
        project = QgsProject.instance()
        for layer in list(project.mapLayers().values()):
            if layer.name() == nombre:
                project.removeMapLayer(layer.id())

    # ---------- creación de memory layer ----------

    def _crear_memory_layer(self, slug, label, geojson):
        """Crea un QgsVectorLayer en memoria con los features del GeoJSON."""
        tmpfile = None
        try:
            fd, tmpfile = tempfile.mkstemp(suffix='.geojson', prefix=f'smc_{slug}_')
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(geojson, f)
            src_layer = QgsVectorLayer(tmpfile, f'SmartCube · {label}', 'ogr')
            if not src_layer.isValid():
                return None

            # Determinar tipo de geometría del primer feature para construir la URI memory.
            # 0=Point, 1=Line, 2=Polygon (QgsWkbTypes.GeometryType).
            geom_type = src_layer.geometryType()
            geom_str = {0: 'Point', 1: 'LineString', 2: 'Polygon'}.get(geom_type, 'Polygon')

            mem_layer = QgsVectorLayer(
                f'Multi{geom_str}?crs=EPSG:4326',
                f'SmartCube · {label}',
                'memory',
            )
            mem_provider = mem_layer.dataProvider()
            mem_provider.addAttributes(src_layer.fields())
            mem_layer.updateFields()
            feats = list(src_layer.getFeatures())
            if feats:
                mem_provider.addFeatures(feats)
            mem_layer.updateExtents()
            return mem_layer
        except Exception as e:
            self._log(f'✗ Error creando memory layer para {label}: {e}')
            return None
        finally:
            if tmpfile and os.path.exists(tmpfile):
                try:
                    os.unlink(tmpfile)
                except Exception:
                    pass

    # ---------- simbología ----------

    def _aplicar_simbologia(self, slug, layer):
        """Aplica simbología por capa según el slug."""
        try:
            if slug == 'terrenos':
                sym = QgsFillSymbol.createSimple({
                    'color': '100,116,139,20',          # #64748b ~8% alpha
                    'outline_color': '#475569',
                    'outline_width': '0.6',
                    'outline_style': 'dash',
                })
                layer.renderer().setSymbol(sym)
            elif slug == 'unidades':
                # Categorías por planta_ubicacion: 1 azul, 2 rojo, ≥3 verde
                colores = {
                    1: ('43,140,238', '#2b8cee'),
                    2: ('239,68,68',  '#ef4444'),
                    3: ('34,197,94',  '#22c55e'),
                }
                categorias = []
                for planta_val, (rgb, hex_color) in colores.items():
                    sym = QgsFillSymbol.createSimple({
                        'color': f'{rgb},128',  # alpha ~50%
                        'outline_color': hex_color,
                        'outline_width': '0.4',
                    })
                    if planta_val == 3:
                        # Una sola categoría que cubrirá ≥3 vía valor explícito 3
                        # (los valores 4,5,... no entran). Para abarcarlos creamos
                        # múltiples categorías 3..10.
                        for p in range(3, 11):
                            s = QgsFillSymbol.createSimple({
                                'color': f'{rgb},128',
                                'outline_color': hex_color,
                                'outline_width': '0.4',
                            })
                            categorias.append(QgsRendererCategory(p, s, f'Piso {p}'))
                    else:
                        label = 'Piso 1' if planta_val == 1 else 'Piso 2'
                        categorias.append(QgsRendererCategory(planta_val, sym, label))
                # Categoría por defecto (otros valores incluido NULL o pisos bajos)
                sym_default = QgsFillSymbol.createSimple({
                    'color': '156,163,175,80',
                    'outline_color': '#6b7280',
                    'outline_width': '0.3',
                })
                categorias.append(QgsRendererCategory('', sym_default, 'Otros'))
                # Verifica que el campo exista
                fields = [f.name() for f in layer.fields()]
                campo = 'planta_ubicacion' if 'planta_ubicacion' in fields else None
                if campo:
                    renderer = QgsCategorizedSymbolRenderer(campo, categorias)
                    layer.setRenderer(renderer)
                else:
                    # Fallback: color uniforme
                    sym = QgsFillSymbol.createSimple({
                        'color': '43,140,238,128',
                        'outline_color': '#2b8cee',
                        'outline_width': '0.4',
                    })
                    layer.renderer().setSymbol(sym)
            elif slug == 'terrenos_borrador':
                # Categorizado por rol: predio del trámite (ámbar) vs colindante (violeta).
                sym_borr = QgsFillSymbol.createSimple({
                    'color': '251,191,36,40',         # ámbar muy tenue
                    'outline_color': '#d97706',
                    'outline_width': '0.7',
                    'outline_style': 'dash',
                })
                sym_col = QgsFillSymbol.createSimple({
                    'color': '139,92,246,50',         # violeta semitransparente
                    'outline_color': '#7c3aed',
                    'outline_width': '0.7',
                    'outline_style': 'dash',
                })
                fields = [f.name() for f in layer.fields()]
                if 'rol' in fields:
                    cats = [
                        QgsRendererCategory('borrador', sym_borr, 'Predio del trámite'),
                        QgsRendererCategory('colindante', sym_col, 'Colindante propuesto'),
                    ]
                    layer.setRenderer(QgsCategorizedSymbolRenderer('rol', cats))
                else:
                    layer.renderer().setSymbol(sym_borr)
            elif slug == 'unidades_borrador':
                sym = QgsFillSymbol.createSimple({
                    'color': '249,115,22,60',         # naranja semitransparente
                    'outline_color': '#c2410c',
                    'outline_width': '0.5',
                    'outline_style': 'dash',
                })
                layer.renderer().setSymbol(sym)
            elif slug == 'manzanas':
                sym = QgsFillSymbol.createSimple({
                    'color': '0,0,0,0',
                    'outline_color': '#000000',
                    'outline_width': '0.4',
                })
                layer.renderer().setSymbol(sym)
            elif slug == 'sectores':
                sym = QgsFillSymbol.createSimple({
                    'color': '0,0,0,0',
                    'outline_color': '#2563eb',
                    'outline_width': '0.6',
                })
                layer.renderer().setSymbol(sym)
            elif slug == 'veredas':
                sym = QgsFillSymbol.createSimple({
                    'color': '0,0,0,0',
                    'outline_color': '#92400e',
                    'outline_width': '0.4',
                    'outline_style': 'dash',
                })
                layer.renderer().setSymbol(sym)
            elif slug == 'barrios':
                sym = QgsFillSymbol.createSimple({
                    'color': '0,0,0,0',
                    'outline_color': '#15803d',
                    'outline_width': '0.4',
                    'outline_style': 'dash',
                })
                layer.renderer().setSymbol(sym)
            elif slug == 'colindantes':
                sym = QgsFillSymbol.createSimple({
                    'color': '251,191,36,77',  # #fbbf24 ~30% alpha
                    'outline_color': '#d97706',
                    'outline_width': '0.6',
                })
                layer.renderer().setSymbol(sym)
            layer.triggerRepaint()
        except Exception as e:
            self._log(f'⚠ No se pudo aplicar simbología a {slug}: {e}')

    # ---------- utils ----------

    def _log(self, msg):
        self.preview.append(msg)
