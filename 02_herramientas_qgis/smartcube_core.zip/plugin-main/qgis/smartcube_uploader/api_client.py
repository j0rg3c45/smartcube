"""Cliente HTTP del backend SmartCube."""

import json
import logging
import os
import urllib.error
import urllib.parse
import urllib.request
import uuid

logger = logging.getLogger('smartcube')


class ApiError(Exception):
    """Error de comunicación con el backend SmartCube."""

    def __init__(self, message, status=None, body=None):
        super().__init__(message)
        self.status = status
        self.body = body


class SmartcubeClient:
    """Cliente HTTP del backend SmartCube usando solo stdlib (sin requests)."""

    def __init__(self, base_url, token):
        self.base_url = (base_url or '').rstrip('/')
        self.token = token

    def _request(self, method, path, body=None, headers=None, content_type='application/json'):
        url = self.base_url + path
        h = {
            'X-Smartcube-Token': self.token or '',
            'Accept': 'application/json',
        }
        if headers:
            h.update(headers)
        if body is not None and content_type == 'application/json':
            data = json.dumps(body).encode('utf-8')
            h['Content-Type'] = 'application/json'
        else:
            data = body
            if content_type and content_type != 'application/json':
                h['Content-Type'] = content_type

        req = urllib.request.Request(url, data=data, method=method, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                raw = resp.read()
                if raw:
                    return json.loads(raw)
                return None
        except urllib.error.HTTPError as e:
            raw = e.read()
            try:
                body_json = json.loads(raw) if raw else None
            except Exception:
                body_json = {'raw': raw.decode('utf-8', errors='replace')}
            msg = (body_json or {}).get('detail') if isinstance(body_json, dict) else None
            raise ApiError(msg or f'HTTP {e.code}', status=e.code, body=body_json)
        except urllib.error.URLError as e:
            raise ApiError(f'No se pudo conectar: {e.reason}')
        except Exception as e:
            raise ApiError(f'Error inesperado: {e}')

    def test_connection(self):
        return self._request('GET', '/api/gestion/cargas/mis-tramites/')

    def mis_tramites(self):
        return self._request('GET', '/api/gestion/cargas/mis-tramites/')

    def cargar_capa(self, slug, filtros):
        """Llama GET /api/cartografia/qgis/<slug>/ con los filtros como query string.

        Filtra valores vacíos. Devuelve el GeoJSON FeatureCollection.
        """
        qs = {k: v for k, v in (filtros or {}).items() if v not in (None, '', [])}
        path = f'/api/cartografia/qgis/{slug}/'
        if qs:
            path += '?' + urllib.parse.urlencode(qs)
        return self._request('GET', path)

    def mis_tramites_para_filtro(self):
        """Reusa mis_tramites; expuesto aparte para claridad."""
        return self.mis_tramites()

    def upload_terreno(self, tramite_t_id, predio_t_id, zip_path):
        return self._upload_zip(
            f'/api/gestion/cargas/{tramite_t_id}/terreno/',
            zip_path,
            extra_fields={'predio_t_id': str(predio_t_id)},
        )

    def upload_terreno_segregacion(self, tramite_t_id, zip_path):
        """Modo Asignación NPN: sube el matriz (rotulado con su NPN) + polígonos
        nuevos SIN NPN. No requiere predio_t_id."""
        return self._upload_zip(
            f'/api/gestion/cargas/{tramite_t_id}/terreno-segregacion/',
            zip_path,
        )

    def upload_actualizacion_cartografia(self, zip_path, capa, motivo):
        """Actualización cartográfica: corrige la geometría de predios ya
        inscritos. NO va contra un trámite —no hay mutación ni resolución—, así
        que no pide `tramite_t_id`: el shape trae los NPN y el módulo los
        resuelve. Queda pendiente de que un admin la revise y la apruebe.
        """
        return self._upload_zip(
            '/api/cartografia/actualizacion/cargar/',
            zip_path,
            extra_fields={'capa': capa, 'motivo': motivo},
        )

    def upload_construccion(self, tramite_t_id, zip_path):
        return self._upload_zip(
            f'/api/gestion/cargas/{tramite_t_id}/construcciones/',
            zip_path,
        )

    def _upload_zip(self, path, zip_path, extra_fields=None):
        boundary = uuid.uuid4().hex
        body = self._build_multipart(zip_path, boundary, extra_fields or {})
        return self._request(
            'POST', path, body=body,
            content_type=f'multipart/form-data; boundary={boundary}',
        )

    def _build_multipart(self, zip_path, boundary, extra_fields):
        """Arma el cuerpo multipart/form-data en bytes."""
        crlf = b'\r\n'
        parts = []
        for name, value in extra_fields.items():
            parts.append(f'--{boundary}'.encode())
            parts.append(f'Content-Disposition: form-data; name="{name}"'.encode())
            parts.append(b'')
            parts.append(str(value).encode('utf-8'))
        # archivo
        filename = os.path.basename(zip_path)
        parts.append(f'--{boundary}'.encode())
        parts.append(
            f'Content-Disposition: form-data; name="zip"; filename="{filename}"'.encode()
        )
        parts.append(b'Content-Type: application/zip')
        parts.append(b'')
        with open(zip_path, 'rb') as f:
            parts.append(f.read())
        parts.append(f'--{boundary}--'.encode())
        parts.append(b'')
        return crlf.join(parts)
