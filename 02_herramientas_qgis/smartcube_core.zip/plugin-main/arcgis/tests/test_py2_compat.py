# -*- coding: utf-8 -*-
"""Guard: el código que corre dentro de ArcMap (py2.7) no puede usar f-strings."""
import io
import glob
import os
import re

TOOLBOX_DIR = os.path.join(os.path.dirname(__file__), '..', 'toolbox')
F_STRING = re.compile(r"""(?<![A-Za-z0-9_])[fF]['"]""")


def _fuentes():
    patrones = [os.path.join(TOOLBOX_DIR, '*.pyt'),
                os.path.join(TOOLBOX_DIR, 'smartcube_core', '*.py')]
    rutas = []
    for p in patrones:
        rutas.extend(glob.glob(p))
    return rutas


def test_hay_fuentes():
    assert len(_fuentes()) >= 4


def test_sin_f_strings():
    infractores = []
    for ruta in _fuentes():
        with io.open(ruta, 'r', encoding='utf-8') as f:
            for num, linea in enumerate(f, 1):
                if F_STRING.search(linea):
                    infractores.append('{0}:{1}: {2}'.format(
                        os.path.basename(ruta), num, linea.strip()))
    assert not infractores, 'f-strings prohibidas (py2.7):\n' + '\n'.join(infractores)
