# -*- coding: utf-8 -*-
from smartcube_core import labels


def test_build_tramite_label():
    t = {'tramite_t_id': 42, 'radicado_numero': 'R-2026-001',
         'mutacion_tipo': 'Segunda', 'predios': [{}, {}]}
    assert labels.build_tramite_label(t) == 'R-2026-001 · Segunda · (2 predio/s) [#42]'


def test_build_tramite_label_datos_faltantes():
    t = {'tramite_t_id': 7}
    assert labels.build_tramite_label(t) == '? · ? · (0 predio/s) [#7]'


def test_build_predio_label_simple():
    p = {'predio_t_id': 9, 'npn': '760010001', 'npn_principal_esperado': '760010001',
         'npn_esperado_listo': True}
    assert labels.build_predio_label(p) == '760010001 [#9]'


def test_build_predio_label_npn_nuevo():
    p = {'predio_t_id': 9, 'npn': '760010001', 'npn_principal_esperado': '760010002',
         'npn_esperado_listo': True}
    assert labels.build_predio_label(p) == '760010001 → 760010002 (NUEVO) [#9]'


def test_build_predio_label_paso1_incompleto():
    p = {'predio_t_id': 9, 'npn': '760010001', 'npn_esperado_listo': False}
    out = labels.build_predio_label(p)
    assert 'paso 1 incompleto' in out and out.endswith('[#9]')


def test_parse_id():
    assert labels.parse_id('R-1 · Segunda · (2 predio/s) [#42]') == 42
    assert labels.parse_id('sin id') is None
    assert labels.parse_id('') is None
    assert labels.parse_id(None) is None
