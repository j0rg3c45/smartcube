# -*- coding: utf-8 -*-
"""El toolbox de ArcGIS publica shapes por el mismo camino que el plugin de
QGIS, así que arrastra el mismo riesgo: una capa en un CRS que el backend no
sabe interpretar entra al borrador como coordenadas sin sentido.

La lógica es una copia literal de `plugin/qgis/smartcube_uploader/crs.py`; el
último test vigila que las dos copias no se separen.
"""
import io
import os

from smartcube_core.crs import (
    CRS_SOPORTADOS,
    es_soportado,
    mensaje_crs_no_soportado,
)


class TestEsSoportado(object):
    def test_wgs84_y_origen_unico_son_soportados(self):
        assert es_soportado('EPSG:4326')
        assert es_soportado('EPSG:9377')

    def test_magna_sirgas_con_codigo_esri_es_soportado(self):
        """`factoryCode` devuelve 103599 para MAGNA-SIRGAS_Origen-Nacional."""
        assert es_soportado('EPSG:103599')
        assert es_soportado('ESRI:103599')

    def test_magna_bogota_no_es_soportado(self):
        assert not es_soportado('EPSG:3116')

    def test_capa_sin_crs_no_es_soportada(self):
        assert not es_soportado('')


class TestMensaje(object):
    def test_nombra_el_crs_encontrado(self):
        assert 'EPSG:3116' in mensaje_crs_no_soportado('EPSG:3116')

    def test_hay_exactamente_dos_crs_admitidos(self):
        assert set(CRS_SOPORTADOS) == {'EPSG:4326', 'EPSG:9377'}


class TestCopiasSincronizadas(object):
    def test_el_modulo_es_identico_al_del_plugin_qgis(self):
        """Si alguien corrige la regla en un plugin, debe corregirla en el otro."""
        aqui = os.path.dirname(os.path.abspath(__file__))
        raiz = os.path.abspath(os.path.join(aqui, '..', '..'))
        arcgis = os.path.join(raiz, 'arcgis', 'toolbox', 'smartcube_core', 'crs.py')
        qgis = os.path.join(raiz, 'qgis', 'smartcube_uploader', 'crs.py')

        with io.open(arcgis, encoding='utf-8') as fh:
            contenido_arcgis = fh.read()
        with io.open(qgis, encoding='utf-8') as fh:
            contenido_qgis = fh.read()

        assert contenido_arcgis == contenido_qgis, (
            'plugin/arcgis/.../crs.py y plugin/qgis/.../crs.py divergieron; '
            'la regla de CRS debe ser la misma en los dos plugins.'
        )
