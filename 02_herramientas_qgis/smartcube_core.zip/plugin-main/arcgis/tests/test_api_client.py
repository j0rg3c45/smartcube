# -*- coding: utf-8 -*-
import io
import json

import pytest

from smartcube_core import api_client, compat


class FakeResponse(object):
    def __init__(self, payload):
        self._raw = json.dumps(payload).encode('utf-8')

    def read(self):
        return self._raw

    def close(self):
        pass


def test_mis_tramites_ok(monkeypatch):
    capturado = {}

    def fake_urlopen(req, timeout=None):
        capturado['url'] = req.get_full_url()
        capturado['token'] = req.headers.get('X-smartcube-token')
        return FakeResponse([{'tramite_t_id': 1}])

    monkeypatch.setattr(api_client.compat, 'urlopen', fake_urlopen)
    client = api_client.SmartcubeClient('http://x:7000/', 'smc_tok')
    assert client.mis_tramites() == [{'tramite_t_id': 1}]
    assert capturado['url'] == 'http://x:7000/api/gestion/cargas/mis-tramites/'
    assert capturado['token'] == 'smc_tok'


def test_http_error_extrae_detail(monkeypatch):
    def fake_urlopen(req, timeout=None):
        raise compat.HTTPError(
            req.get_full_url(), 401, 'Unauthorized', {},
            io.BytesIO(b'{"detail": "Token invalido"}'))

    monkeypatch.setattr(api_client.compat, 'urlopen', fake_urlopen)
    client = api_client.SmartcubeClient('http://x', 't')
    with pytest.raises(api_client.ApiError) as exc:
        client.mis_tramites()
    assert exc.value.status == 401
    assert 'Token invalido' in str(exc.value)


def test_url_error(monkeypatch):
    def fake_urlopen(req, timeout=None):
        raise compat.URLError('conexion rechazada')

    monkeypatch.setattr(api_client.compat, 'urlopen', fake_urlopen)
    client = api_client.SmartcubeClient('http://x', 't')
    with pytest.raises(api_client.ApiError) as exc:
        client.mis_tramites()
    assert 'No se pudo conectar' in str(exc.value)


def test_url_error_reason_bytes_latin1(monkeypatch):
    # Windows en español entrega e.reason como bytes latin-1 ("conexión…");
    # en py2 esto reventaba con UnicodeDecodeError al formatear el mensaje.
    def fake_urlopen(req, timeout=None):
        raise compat.URLError(b'No se puede establecer una conexi\xf3n')

    monkeypatch.setattr(api_client.compat, 'urlopen', fake_urlopen)
    client = api_client.SmartcubeClient('http://x', 't')
    with pytest.raises(api_client.ApiError) as exc:
        client.mis_tramites()
    assert 'conexión' in str(exc.value)


def test_build_multipart(tmp_path):
    zip_file = tmp_path / 'capa.zip'
    zip_file.write_bytes(b'PK-fake-zip')
    client = api_client.SmartcubeClient('http://x', 't')
    body = client._build_multipart(str(zip_file), 'BOUND', {'predio_t_id': '9'})
    texto = body.decode('utf-8', 'replace')
    assert 'name="predio_t_id"' in texto
    assert '\r\n9\r\n' in texto
    assert 'name="zip"; filename="capa.zip"' in texto
    assert 'Content-Type: application/zip' in texto
    assert b'PK-fake-zip' in body
    assert texto.rstrip().endswith('--BOUND--')


def test_upload_terreno_arma_url_y_multipart(monkeypatch, tmp_path):
    zip_file = tmp_path / 'capa.zip'
    zip_file.write_bytes(b'PK')
    capturado = {}

    def fake_urlopen(req, timeout=None):
        capturado['url'] = req.get_full_url()
        capturado['method'] = req.get_method()
        capturado['ctype'] = req.headers.get('Content-type')
        return FakeResponse({'carga_t_id': 5, 'count_features': 2})

    monkeypatch.setattr(api_client.compat, 'urlopen', fake_urlopen)
    client = api_client.SmartcubeClient('http://x', 't')
    resp = client.upload_terreno(3, 9, str(zip_file))
    assert resp['carga_t_id'] == 5
    assert capturado['url'] == 'http://x/api/gestion/cargas/3/terreno/'
    assert capturado['method'] == 'POST'
    assert capturado['ctype'].startswith('multipart/form-data; boundary=')
