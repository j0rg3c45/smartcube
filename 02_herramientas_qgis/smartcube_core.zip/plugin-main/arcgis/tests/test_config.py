# -*- coding: utf-8 -*-
import io

from smartcube_core import config


def _usar_tmp(monkeypatch, tmp_path):
    path = tmp_path / 'cfg' / 'arcgis_config.json'
    monkeypatch.setenv('SMARTCUBE_ARCGIS_CONFIG', str(path))
    return path


def test_load_sin_archivo_devuelve_defaults(monkeypatch, tmp_path):
    _usar_tmp(monkeypatch, tmp_path)
    cfg = config.load()
    assert cfg == {'backend_url': 'http://localhost:7000', 'api_token': ''}


def test_save_y_load_roundtrip(monkeypatch, tmp_path):
    _usar_tmp(monkeypatch, tmp_path)
    config.save('https://jamundi.smartcubescol.com', 'smc_abc123')
    cfg = config.load()
    assert cfg == {'backend_url': 'https://jamundi.smartcubescol.com',
                   'api_token': 'smc_abc123'}


def test_load_archivo_corrupto_devuelve_defaults(monkeypatch, tmp_path):
    path = _usar_tmp(monkeypatch, tmp_path)
    path.parent.mkdir(parents=True)
    with io.open(str(path), 'w', encoding='utf-8') as f:
        f.write('{esto no es json')
    cfg = config.load()
    assert cfg == {'backend_url': 'http://localhost:7000', 'api_token': ''}
