# SmartCube Toolbox — ArcMap 10.8 y ArcGIS Pro

Python Toolbox (`.pyt`) **compartido** para publicar shapefiles de terreno y unidades de
construcción a trámites SmartCube. El mismo archivo funciona en **ArcMap 10.8**
(Python 2.7) y **ArcGIS Pro** (Python 3) — sin instalaciones ni dependencias externas.

Es el equivalente Esri del plugin de QGIS (`qgis/smartcube_uploader/`): usa el mismo
API token y los mismos endpoints del backend.

## Instalación

1. Descarga `smartcube_toolbox-<version>.zip` (o constrúyelo con `bash arcgis/build.sh`)
   y descomprímelo en una carpeta permanente (p. ej. `C:\SmartCube\toolbox\`).
   También puedes clonar el repo y usar `arcgis/toolbox/` directamente.
2. Agrega el toolbox:
   - **ArcMap**: ventana ArcToolbox → clic derecho → **Add Toolbox…** → selecciona
     `SmartCube.pyt`.
   - **ArcGIS Pro**: pestaña **Catalog** → **Toolboxes** → clic derecho → **Add Toolbox** →
     selecciona `SmartCube.pyt`.
3. Verás el toolbox **SmartCube** con dos herramientas.

> ⚠ No muevas ni renombres la carpeta después de agregar el toolbox: ArcGIS guarda la
> ruta. Si la mueves, vuelve a agregarlo.

## Configuración

1. Genera un API token en SmartCube web: `/perfil` → sección **Tokens API** →
   **Crear token** → copia el `smc_xxx…` (se muestra una sola vez).
2. Ejecuta la herramienta **«1. Configurar conexión»**: pega la URL del backend
   (p. ej. `https://jamundi.smartcubescol.com`) y el token.
3. Al ejecutar, guarda la configuración y prueba la conexión: si tu rol y token son
   correctos verás `✓ Conexión exitosa. N trámite(s) accesibles.`

La configuración queda en `%APPDATA%\SmartCube\arcgis_config.json`. El token se guarda
en texto plano (mismo nivel de protección que la configuración del plugin QGIS): no
compartas ese archivo.

## Uso

1. Abre en el mapa la capa a publicar. Verifica que trae el campo `NPN` (terreno) o
   `NPN` + `identificador` (construcción).
2. Ejecuta **«2. Publicar shape»**:
   - **Trámite**: lista de trámites donde el analista te invitó como cargador.
   - **Capa destino**: `Terreno`, `Terreno · Asignación NPN` o `Construcción`.
   - **Predio**: solo para `Terreno`. La etiqueta muestra el NPN a rotular
     (`npn → npn_nuevo (NUEVO)` si el trámite crea predio) y avisa si el Paso 1
     del wizard está incompleto.
   - **Capa a publicar**: capa del mapa o ruta a shapefile/feature class.
3. Ejecutar. El toolbox exporta la capa a Shapefile.zip y la envía al backend; el
   analista verá el shape en el wizard del trámite (Paso 3 o Paso 4).

> ℹ Si la capa tiene una **selección activa**, solo se publican los features
> seleccionados (comportamiento estándar de ArcGIS; en QGIS siempre se sube todo).

## Errores comunes

| Error | Causa probable |
|-------|----------------|
| `✗ Token inválido o revocado` (401) | El token no existe o fue revocado. Genera uno nuevo y ejecuta «1. Configurar conexión». |
| `403 Forbidden` | El analista no te ha invitado al trámite. Pídele que te invite desde `/asignacion`. |
| `400 NPN no coincide` | El shape no trae un polígono con el NPN del predio seleccionado. Revisa la columna NPN del DBF. |
| `409 Trámite cerrado` | El trámite ya fue aprobado o rechazado. Solicita uno nuevo. |
| `No se pudo conectar` | URL mal escrita, sin red, o backend caído. |
| El dropdown Trámite muestra `✗ …` | Falló la carga de trámites al abrir la herramienta. Ejecuta «1. Configurar conexión» y vuelve a abrir. |

## Desarrollo

- `toolbox/smartcube_core/` es lógica pura (stdlib, **sin arcpy**) compatible
  Python 2.7/3. `SmartCube.pyt` es la única capa que toca `arcpy`.
- **Regla dura:** nada de f-strings ni sintaxis exclusiva de py3 en `toolbox/` —
  ArcMap lo ejecuta con Python 2.7.18. Hay un test guard que lo verifica.
- Tests (no requieren ArcGIS): `python -m pytest arcgis/tests -v`
- Tras editar el `.pyt` con ArcGIS abierto: clic derecho al toolbox → **Refresh**.

## Checklist E2E (ejecutar en ArcMap 10.8 Y en ArcGIS Pro)

Contra el backend dev (`http://localhost:7000`), con un usuario con rol
`user-cargador-shape`, token vigente e invitación de cargador en un trámite:

- [ ] «1. Configurar conexión» con token válido → `✓ Conexión exitosa, N trámite(s)`.
- [ ] «1. Configurar conexión» con token inventado → error 401 legible.
- [ ] «2. Publicar shape» abre con los trámites en el dropdown (formato `radicado · mutación · (N predio/s) [#id]`).
- [ ] Elegir destino `Construcción` → el campo Predio se deshabilita.
- [ ] Elegir destino `Terreno` + predio → warning con el NPN a rotular.
- [ ] Publicar Terreno con shape válido → `✓ Carga creada` con conteos; el shape aparece en el wizard (Paso 3).
- [ ] Publicar Construcción con shape válido → `✓ Carga creada` con conteo de UC (Paso 4).
- [ ] Publicar Terreno · Asignación NPN en un trámite de segregación → `✓ Carga de segregación creada`.
- [ ] Publicar con NPN que no coincide → error 400 con el detalle del backend.
- [ ] Revocar el token en `/perfil` y publicar → mensaje de token inválido con instrucción de reconfigurar.
- [ ] Capa con selección activa → solo se publican los features seleccionados.

## Licencia

Uso interno de SmartCube. Todos los derechos reservados.
