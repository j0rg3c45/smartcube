# -*- coding: utf-8 -*-
"""Etiquetas de dropdowns con el t_id embebido — evita estado compartido
entre eventos del diálogo de geoprocesamiento."""
from __future__ import absolute_import, unicode_literals

import re

_ID_RE = re.compile(r'\[#(\d+)\]\s*$')


def build_tramite_label(t):
    predios = t.get('predios') or []
    return '{0} · {1} · ({2} predio/s) [#{3}]'.format(
        t.get('radicado_numero') or '?',
        t.get('mutacion_tipo') or '?',
        len(predios),
        t['tramite_t_id'],
    )


def build_predio_label(p):
    npn = p.get('npn') or ''
    esperado = p.get('npn_principal_esperado') or ''
    if esperado and esperado != npn:
        base = '{0} → {1} (NUEVO)'.format(npn, esperado)
    else:
        base = npn or '?'
    if not p.get('npn_esperado_listo'):
        base += '  ⚠ paso 1 incompleto'
    return '{0} [#{1}]'.format(base, p['predio_t_id'])


def parse_id(label):
    m = _ID_RE.search(label or '')
    return int(m.group(1)) if m else None
