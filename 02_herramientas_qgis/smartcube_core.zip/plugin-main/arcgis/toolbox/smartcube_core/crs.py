# -*- coding: utf-8 -*-
"""Sistemas de referencia admitidos al publicar una capa a SmartCube.

Por qué se valida aquí y no solo en el servidor: el backend deduce el CRS del
`.prj` que viaja en el ZIP, y esa deducción **falla en abierto hacia EPSG:4326**
(el `.prj` es opcional, y el WKT estilo ESRI no siempre trae el código EPSG).
Una capa en metros publicada sin `.prj` legible entra al borrador etiquetada
como grados, no protesta en el momento y revienta días después al commitear el
trámite. Cortarlo en el diálogo es más barato y el mensaje llega a quien puede
arreglarlo.

Módulo deliberadamente puro: no importa `qgis` ni `arcpy`, para poder probarlo
sin el entorno SIG. Copia idéntica en el toolbox de ArcGIS
(`plugin/arcgis/toolbox/smartcube_core/crs.py`).
"""

CRS_SOPORTADOS = {
    'EPSG:4326': 'WGS 84 (grados)',
    'EPSG:9377': 'MAGNA-SIRGAS / Origen Unico Nacional (metros)',
}

# Mismos sistemas, otro catalogo. Un `.prj` escrito en WKT estilo ESRI
# (`PROJCS["MAGNA-SIRGAS_Origen-Nacional", ...]`, que es lo que sale de ArcGIS y
# de buena parte de la cartografia que llega de los municipios) no lleva nodos
# AUTHORITY, asi que QGIS no puede resolverlo al codigo EPSG y lo etiqueta
# ESRI:103599. Es el mismo origen unico nacional que EPSG:9377 —mismos
# parametros— y el backend lo identifica por nombre, de modo que rechazarlo era
# un falso positivo que dejaba al cargador sin salida.
#
# ArcGIS expone ese mismo 103599 en `spatialReference.factoryCode`, y
# `authid_desde_codigo_epsg` lo prefija como EPSG: por eso las dos formas.
CRS_EQUIVALENTES = {
    'ESRI:103599': 'EPSG:9377',
    'EPSG:103599': 'EPSG:9377',
    # WGS 84 en orden lon/lat: el mismo 4326 con el que se escriben los GeoJSON.
    'OGC:CRS84': 'EPSG:4326',
}


def _normalizar(authid):
    if not authid:
        return ''
    return str(authid).strip().upper()


def _canonizar(authid):
    """authid normalizado y resuelto a su equivalente EPSG soportado."""
    normalizado = _normalizar(authid)
    return CRS_EQUIVALENTES.get(normalizado, normalizado)


def authid_desde_codigo_epsg(codigo):
    """Convierte un codigo EPSG numerico en authid ('EPSG:9377').

    ArcGIS expone el CRS como `spatialReference.factoryCode`, que vale 0
    cuando la capa no tiene sistema de referencia definido. Devuelve cadena
    vacia para todo lo que no sea un codigo utilizable.
    """
    try:
        numero = int(codigo)
    except (TypeError, ValueError):
        return ''
    if numero <= 0:
        return ''
    return 'EPSG:%d' % numero


def es_soportado(authid):
    """True si el CRS de la capa es uno de los dos que el backend maneja.

    Acepta tambien los codigos equivalentes de otros catalogos
    (`CRS_EQUIVALENTES`): identifican el mismo sistema, solo cambia quien lo
    numera.
    """
    return _canonizar(authid) in CRS_SOPORTADOS


def mensaje_crs_no_soportado(authid):
    """Texto para el diálogo cuando la capa no se puede publicar."""
    aceptados = '\n'.join(
        '  - %s  (%s)' % (codigo, nombre)
        for codigo, nombre in sorted(CRS_SOPORTADOS.items())
    )
    encontrado = _normalizar(authid)
    if not encontrado:
        cabecera = (
            'La capa esta sin sistema de referencia definido, asi que no se '
            'puede saber que significan sus coordenadas.'
        )
    else:
        cabecera = (
            'La capa esta en %s, que SmartCube no admite para publicacion.'
            % encontrado
        )
    return (
        '%s\n\n'
        'Sistemas admitidos:\n%s\n\n'
        'Reproyecta la capa en QGIS (clic derecho > Exportar > Guardar objetos '
        'como..., eligiendo el SRC de destino) y vuelve a publicar.'
        % (cabecera, aceptados)
    )
