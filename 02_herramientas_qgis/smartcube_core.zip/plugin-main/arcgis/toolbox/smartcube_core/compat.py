# -*- coding: utf-8 -*-
"""Shims de compatibilidad Python 2.7 (ArcMap 10.8) / Python 3 (ArcGIS Pro)."""
from __future__ import absolute_import, unicode_literals

import sys

PY2 = sys.version_info[0] == 2

if PY2:
    from urllib2 import Request as _Py2Request, urlopen, HTTPError, URLError  # noqa: F401

    class Request(_Py2Request):
        """urllib2.Request de py2 no acepta method=; este shim lo agrega."""

        def __init__(self, url, data=None, headers=None, method=None):
            _Py2Request.__init__(self, url, data=data, headers=headers or {})
            self._method = method

        def get_method(self):
            if self._method:
                return self._method
            return _Py2Request.get_method(self)
else:
    from urllib.request import Request, urlopen  # noqa: F401
    from urllib.error import HTTPError, URLError  # noqa: F401


def ensure_text(value):
    """Devuelve texto unicode a partir de bytes o texto."""
    if isinstance(value, bytes):
        return value.decode('utf-8', 'replace')
    return value


def safe_text(value):
    """Texto unicode desde cualquier valor, incluidos bytes en encoding
    incierto (p.ej. e.reason de Windows en español llega en latin-1)."""
    if isinstance(value, bytes):
        try:
            return value.decode('utf-8')
        except UnicodeDecodeError:
            return value.decode('latin-1', 'replace')
    try:
        return '{0}'.format(value)
    except UnicodeDecodeError:
        # py2: unicode(obj) implícito sobre un str no-ascii
        return safe_text(str(value))
