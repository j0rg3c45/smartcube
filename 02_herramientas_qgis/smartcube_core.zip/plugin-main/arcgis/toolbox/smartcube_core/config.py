# -*- coding: utf-8 -*-
"""Configuración persistente (URL backend + token) en %APPDATA%\\SmartCube."""
from __future__ import absolute_import, unicode_literals

import io
import json
import os

DEFAULT_URL = 'http://localhost:7000'


def config_path():
    override = os.environ.get('SMARTCUBE_ARCGIS_CONFIG')
    if override:
        return override
    base = os.environ.get('APPDATA') or os.path.expanduser('~')
    return os.path.join(base, 'SmartCube', 'arcgis_config.json')


def load():
    try:
        with io.open(config_path(), 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            data = {}
    except (IOError, OSError, ValueError):
        data = {}
    return {
        'backend_url': data.get('backend_url') or DEFAULT_URL,
        'api_token': data.get('api_token') or '',
    }


def save(backend_url, api_token):
    path = config_path()
    directory = os.path.dirname(path)
    if directory and not os.path.isdir(directory):
        os.makedirs(directory)
    text = json.dumps(
        {'backend_url': backend_url, 'api_token': api_token},
        ensure_ascii=False, indent=2,
    )
    if isinstance(text, bytes):  # py2: dumps puede devolver str
        text = text.decode('utf-8')
    with io.open(path, 'w', encoding='utf-8') as f:
        f.write(text)
    return path
