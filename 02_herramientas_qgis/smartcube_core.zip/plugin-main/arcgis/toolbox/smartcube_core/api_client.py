# -*- coding: utf-8 -*-
"""Cliente HTTP del backend SmartCube — port del plugin QGIS, py2.7/py3."""
from __future__ import absolute_import, unicode_literals

import json
import os
import uuid

from . import compat


class ApiError(Exception):
    """Error de comunicación con el backend SmartCube."""

    def __init__(self, message, status=None, body=None):
        Exception.__init__(self, message)
        self.status = status
        self.body = body


class SmartcubeClient(object):
    """Cliente HTTP usando solo stdlib (sin requests)."""

    def __init__(self, base_url, token):
        self.base_url = (base_url or '').rstrip('/')
        self.token = token

    def _request(self, method, path, body=None, content_type='application/json'):
        url = self.base_url + path
        headers = {
            'X-Smartcube-Token': self.token or '',
            'Accept': 'application/json',
        }
        if body is not None and content_type == 'application/json':
            data = json.dumps(body).encode('utf-8')
            headers['Content-Type'] = 'application/json'
        else:
            data = body
            if content_type:
                headers['Content-Type'] = content_type

        req = compat.Request(url, data=data, headers=headers, method=method)
        try:
            resp = compat.urlopen(req, timeout=60)
            try:
                raw = resp.read()
            finally:
                resp.close()
            if raw:
                return json.loads(raw.decode('utf-8'))
            return None
        except compat.HTTPError as e:
            raw = e.read()
            try:
                body_json = json.loads(raw.decode('utf-8')) if raw else None
            except Exception:
                body_json = {'raw': compat.ensure_text(raw)}
            msg = None
            if isinstance(body_json, dict):
                msg = body_json.get('detail')
            raise ApiError(msg or 'HTTP {0}'.format(e.code),
                           status=e.code, body=body_json)
        except compat.URLError as e:
            raise ApiError('No se pudo conectar: {0}'.format(
                compat.safe_text(e.reason)))

    def test_connection(self):
        return self._request('GET', '/api/gestion/cargas/mis-tramites/')

    def mis_tramites(self):
        return self._request('GET', '/api/gestion/cargas/mis-tramites/')

    def upload_terreno(self, tramite_t_id, predio_t_id, zip_path):
        return self._upload_zip(
            '/api/gestion/cargas/{0}/terreno/'.format(tramite_t_id),
            zip_path,
            extra_fields={'predio_t_id': '{0}'.format(predio_t_id)},
        )

    def upload_terreno_segregacion(self, tramite_t_id, zip_path):
        """Modo Asignación NPN: matriz rotulado con su NPN + polígonos nuevos
        sin NPN. No requiere predio_t_id."""
        return self._upload_zip(
            '/api/gestion/cargas/{0}/terreno-segregacion/'.format(tramite_t_id),
            zip_path,
        )

    def upload_construccion(self, tramite_t_id, zip_path):
        return self._upload_zip(
            '/api/gestion/cargas/{0}/construcciones/'.format(tramite_t_id),
            zip_path,
        )

    def _upload_zip(self, path, zip_path, extra_fields=None):
        boundary = uuid.uuid4().hex
        body = self._build_multipart(zip_path, boundary, extra_fields or {})
        return self._request(
            'POST', path, body=body,
            content_type='multipart/form-data; boundary={0}'.format(boundary),
        )

    def _build_multipart(self, zip_path, boundary, extra_fields):
        """Arma el cuerpo multipart/form-data en bytes."""
        crlf = b'\r\n'
        parts = []
        for name, value in extra_fields.items():
            parts.append('--{0}'.format(boundary).encode('utf-8'))
            parts.append(
                'Content-Disposition: form-data; name="{0}"'.format(name)
                .encode('utf-8'))
            parts.append(b'')
            parts.append('{0}'.format(value).encode('utf-8'))
        filename = os.path.basename(zip_path)
        parts.append('--{0}'.format(boundary).encode('utf-8'))
        parts.append(
            'Content-Disposition: form-data; name="zip"; filename="{0}"'
            .format(filename).encode('utf-8'))
        parts.append(b'Content-Type: application/zip')
        parts.append(b'')
        with open(zip_path, 'rb') as f:
            parts.append(f.read())
        parts.append('--{0}--'.format(boundary).encode('utf-8'))
        parts.append(b'')
        return crlf.join(parts)
