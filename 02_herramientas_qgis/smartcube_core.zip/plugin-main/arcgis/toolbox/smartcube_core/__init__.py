# -*- coding: utf-8 -*-
"""Lógica pura del toolbox SmartCube (sin arcpy, compatible py2.7/py3)."""
__version__ = '0.1.0'
