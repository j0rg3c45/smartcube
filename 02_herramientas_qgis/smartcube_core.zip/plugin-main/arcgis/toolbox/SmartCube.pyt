# -*- coding: utf-8 -*-
"""SmartCube Toolbox — publica shapefiles a trámites SmartCube.

Compatible con ArcMap 10.8 (Python 2.7) y ArcGIS Pro (Python 3).
Instalación: Add Toolbox → este archivo. Ver arcgis/README.md.
"""
from __future__ import unicode_literals

import os
import shutil
import sys
import tempfile
import zipfile

import arcpy

_DIR = os.path.dirname(os.path.abspath(__file__))
if _DIR not in sys.path:
    sys.path.insert(0, _DIR)

from smartcube_core import api_client, config, crs, labels  # noqa: E402

DESTINO_TERRENO = 'Terreno'
DESTINO_SEGREGACION = 'Terreno · Asignación NPN'
DESTINO_CONSTRUCCION = 'Construcción'
DESTINOS = [DESTINO_TERRENO, DESTINO_SEGREGACION, DESTINO_CONSTRUCCION]

# Cache de trámites del último getParameterInfo (vive mientras el .pyt esté
# cargado; se refresca cada vez que se abre la herramienta).
_TRAMITES = []


def _client():
    cfg = config.load()
    return api_client.SmartcubeClient(cfg['backend_url'], cfg['api_token'])


def _authid_de(capa):
    """authid del CRS de la capa ('EPSG:9377'), o '' si no tiene o no se puede leer."""
    try:
        sr = arcpy.Describe(capa).spatialReference
    except Exception:
        return ''
    return crs.authid_desde_codigo_epsg(getattr(sr, 'factoryCode', 0))


def _tramite_por_label(label):
    tid = labels.parse_id(label)
    for t in _TRAMITES:
        if t.get('tramite_t_id') == tid:
            return t
    return None


def _predio_por_label(tramite, label):
    pid = labels.parse_id(label)
    for p in (tramite or {}).get('predios') or []:
        if p.get('predio_t_id') == pid:
            return p
    return None


class Toolbox(object):
    def __init__(self):
        self.label = 'SmartCube'
        self.alias = 'smartcube'
        self.tools = [ConfigurarConexion, PublicarShape]


class ConfigurarConexion(object):
    def __init__(self):
        self.label = '1. Configurar conexión'
        self.description = ('Guarda la URL del backend SmartCube y el token API, '
                            'y prueba la conexión listando tus trámites.')
        self.canRunInBackground = False

    def getParameterInfo(self):
        cfg = config.load()
        url = arcpy.Parameter(
            displayName='URL del backend SmartCube',
            name='backend_url', datatype='GPString',
            parameterType='Required', direction='Input')
        url.value = cfg['backend_url']
        token = arcpy.Parameter(
            displayName='Token API (SmartCube web: /perfil → Tokens API)',
            name='api_token', datatype='GPString',
            parameterType='Required', direction='Input')
        if cfg['api_token']:
            token.value = cfg['api_token']
        return [url, token]

    def updateParameters(self, parameters):
        return

    def updateMessages(self, parameters):
        return

    def execute(self, parameters, messages):
        backend_url = (parameters[0].valueAsText or '').strip()
        api_token = (parameters[1].valueAsText or '').strip()
        path = config.save(backend_url, api_token)
        messages.addMessage('Configuración guardada en {0}'.format(path))
        client = api_client.SmartcubeClient(backend_url, api_token)
        try:
            data = client.test_connection() or []
        except api_client.ApiError as e:
            messages.addErrorMessage(
                '✗ Error probando conexión: {0} (status={1})'.format(e, e.status))
            return
        messages.addMessage(
            '✓ Conexión exitosa. {0} trámite(s) accesibles.'.format(len(data)))


class PublicarShape(object):
    def __init__(self):
        self.label = '2. Publicar shape'
        self.description = ('Exporta una capa a Shapefile.zip y la publica a un '
                            'trámite SmartCube (terreno o construcción). Si la capa '
                            'tiene selección activa, solo se publica lo seleccionado.')
        self.canRunInBackground = False

    def getParameterInfo(self):
        global _TRAMITES
        tramite = arcpy.Parameter(
            displayName='Trámite', name='tramite', datatype='GPString',
            parameterType='Required', direction='Input')
        tramite.filter.type = 'ValueList'
        try:
            _TRAMITES = _client().mis_tramites() or []
            tramite.filter.list = [labels.build_tramite_label(t) for t in _TRAMITES]
        except api_client.ApiError as e:
            _TRAMITES = []
            tramite.filter.list = [
                '✗ {0} — ejecuta "1. Configurar conexión"'.format(e)]

        destino = arcpy.Parameter(
            displayName='Capa destino', name='capa_destino', datatype='GPString',
            parameterType='Required', direction='Input')
        destino.filter.type = 'ValueList'
        destino.filter.list = DESTINOS
        destino.value = DESTINO_TERRENO

        predio = arcpy.Parameter(
            displayName='Predio (solo para Terreno)', name='predio',
            datatype='GPString', parameterType='Optional', direction='Input')
        predio.filter.type = 'ValueList'

        capa = arcpy.Parameter(
            displayName='Capa a publicar', name='capa',
            datatype='GPFeatureLayer', parameterType='Required',
            direction='Input')
        return [tramite, destino, predio, capa]

    def updateParameters(self, parameters):
        tramite_p, destino_p, predio_p = parameters[0], parameters[1], parameters[2]
        es_terreno = destino_p.valueAsText == DESTINO_TERRENO
        predio_p.enabled = es_terreno
        t = _tramite_por_label(tramite_p.valueAsText)
        if t is not None:
            predio_p.filter.list = [
                labels.build_predio_label(p) for p in t.get('predios') or []]
        if not es_terreno:
            predio_p.value = None

    def updateMessages(self, parameters):
        tramite_p, destino_p, predio_p = parameters[0], parameters[1], parameters[2]
        label = tramite_p.valueAsText or ''
        if label.startswith('✗'):
            tramite_p.setErrorMessage(
                'No se pudieron cargar los trámites. Ejecuta "1. Configurar '
                'conexión" y vuelve a abrir esta herramienta.')
            return
        es_terreno = destino_p.valueAsText == DESTINO_TERRENO
        if es_terreno and label and not predio_p.valueAsText:
            predio_p.setErrorMessage('Selecciona un predio para destino Terreno.')
            return
        if es_terreno and predio_p.valueAsText:
            t = _tramite_por_label(label)
            p = _predio_por_label(t, predio_p.valueAsText)
            if p is not None and not p.get('npn_esperado_listo'):
                predio_p.setWarningMessage(
                    p.get('aviso') or 'NPN esperado aún no disponible '
                    '(paso 1 incompleto).')
            elif p is not None:
                npn = p.get('npn_principal_esperado') or ''
                es_nuevo = npn and npn != (p.get('npn') or '')
                sufijo = ' (NPN del predio NUEVO asignado en Paso 1)' if es_nuevo else ''
                predio_p.setWarningMessage(
                    'NPN a rotular en el polígono principal del shape: '
                    '{0}{1}'.format(npn, sufijo))

    def execute(self, parameters, messages):
        tramite_label = parameters[0].valueAsText or ''
        destino = parameters[1].valueAsText
        predio_label = parameters[2].valueAsText or ''
        capa = parameters[3].value

        tramite_id = labels.parse_id(tramite_label)
        if not tramite_id:
            messages.addErrorMessage(
                'Trámite inválido. Vuelve a abrir la herramienta (o ejecuta '
                '"1. Configurar conexión" si el problema persiste).')
            return
        predio_id = None
        if destino == DESTINO_TERRENO:
            predio_id = labels.parse_id(predio_label)
            if not predio_id:
                messages.addErrorMessage('Selecciona un predio para destino Terreno.')
                return

        # El backend deduce el CRS del .prj y esa deducción falla en abierto
        # hacia 4326: una capa en metros publicada sin .prj legible entra al
        # borrador etiquetada como grados y revienta al commitear el trámite.
        authid = _authid_de(capa)
        if not crs.es_soportado(authid):
            messages.addErrorMessage(crs.mensaje_crs_no_soportado(authid))
            return

        tmpdir = tempfile.mkdtemp(prefix='smartcube_')
        try:
            shp_path = os.path.join(tmpdir, 'capa.shp')
            messages.addMessage('Exportando capa a Shapefile temporal…')
            arcpy.management.CopyFeatures(capa, shp_path)

            zip_path = os.path.join(tmpdir, 'capa.zip')
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                for ext in ('shp', 'dbf', 'shx', 'prj', 'cpg'):
                    p = os.path.join(tmpdir, 'capa.' + ext)
                    if os.path.exists(p):
                        zf.write(p, 'capa.' + ext)

            client = _client()
            messages.addMessage(
                'Publicando → {0} (trámite #{1})…'.format(destino, tramite_id))
            if destino == DESTINO_TERRENO:
                resp = client.upload_terreno(tramite_id, predio_id, zip_path)
                messages.addMessage(
                    '✓ Carga creada (id={0}). {1} features ({2} colindantes).'.format(
                        resp.get('carga_t_id'), resp.get('count_features'),
                        resp.get('count_colindantes', 0)))
            elif destino == DESTINO_SEGREGACION:
                resp = client.upload_terreno_segregacion(tramite_id, zip_path)
                messages.addMessage(
                    '✓ Carga de segregación creada (id={0}). {1} predios nuevos '
                    'por numerar (matriz {2}).'.format(
                        resp.get('carga_t_id'), resp.get('count_nuevos', 0),
                        resp.get('principal_npn', '?')))
            else:
                resp = client.upload_construccion(tramite_id, zip_path)
                messages.addMessage(
                    '✓ Carga creada (id={0}). {1} features ({2} UC).'.format(
                        resp.get('carga_t_id'), resp.get('count_features'),
                        len(resp.get('identificadores_uc') or [])))
            for w in resp.get('warnings') or []:
                messages.addWarningMessage(w)
            messages.addMessage('Shape publicado correctamente.')
        except api_client.ApiError as e:
            if e.status == 401:
                messages.addErrorMessage(
                    '✗ Token inválido o revocado. Genera uno nuevo en SmartCube '
                    'web (/perfil → Tokens API) y ejecuta "1. Configurar conexión".')
            else:
                messages.addErrorMessage('✗ {0} (status={1})'.format(e, e.status))
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
