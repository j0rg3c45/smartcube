#!/usr/bin/env bash
# Empaqueta el toolbox SmartCube en un .zip distribuible.
#
# Salida: arcgis/dist/smartcube_toolbox-<version>.zip
set -euo pipefail

cd "$(dirname "$0")"

VERSION=$(grep "__version__" toolbox/smartcube_core/__init__.py | cut -d"'" -f2)
OUTDIR="dist"
ZIP_NAME="smartcube_toolbox-${VERSION}.zip"

mkdir -p "$OUTDIR"
rm -f "$OUTDIR/$ZIP_NAME"

# Usa `zip` si está disponible; si no (p.ej. Git Bash en Windows), cae a Python.
if command -v zip >/dev/null 2>&1; then
  zip -r "$OUTDIR/$ZIP_NAME" toolbox \
    -x "toolbox/**/__pycache__/*" \
    -x "toolbox/**/*.pyc"
else
  PYTHON=$(command -v python3 || command -v python)
  "$PYTHON" - "$OUTDIR/$ZIP_NAME" <<'EOF'
import sys, zipfile
from pathlib import Path

dest = Path(sys.argv[1])
with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as zf:
    for path in sorted(Path("toolbox").rglob("*")):
        if "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        if path.is_file():
            zf.write(path, path.as_posix())
EOF
fi

echo "✓ Generado: arcgis/$OUTDIR/$ZIP_NAME"
